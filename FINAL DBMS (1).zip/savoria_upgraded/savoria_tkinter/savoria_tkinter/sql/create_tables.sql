-- ============================================================
--  Savoria — SQL Server Schema (SSMS)
--  Converted from MySQL original (savoria-with-php-backend)
--
--  Run this in SSMS:
--    1. Open SSMS → connect to your server
--    2. Open this file → Execute (F5)
-- ============================================================

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'savoria_db')
    CREATE DATABASE savoria_db;
GO
USE savoria_db;
GO

-- ============================================================
--  1. Users
-- ============================================================
IF OBJECT_ID('Users','U') IS NULL
CREATE TABLE Users (
    user_id    INT            IDENTITY(1,1) PRIMARY KEY,
    name       NVARCHAR(100)  NOT NULL,
    email      NVARCHAR(150)  NOT NULL,
    phone      NVARCHAR(30)   NOT NULL DEFAULT '',
    address    NVARCHAR(300)  NOT NULL DEFAULT '',
    password   NVARCHAR(255)  NOT NULL,
    role       NVARCHAR(20)   NOT NULL DEFAULT 'customer',
    is_deleted BIT            NOT NULL DEFAULT 0,
    created_at DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_Users_Email CHECK (email LIKE '%@%'),
    CONSTRAINT CK_Users_Role  CHECK (role IN ('customer','owner','admin'))
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Users_Email')
    CREATE UNIQUE INDEX IX_Users_Email ON Users(email);
GO

-- ============================================================
--  2. Restaurants
-- ============================================================
IF OBJECT_ID('Restaurants','U') IS NULL
CREATE TABLE Restaurants (
    restaurant_id INT           IDENTITY(1,1) PRIMARY KEY,
    owner_id      INT           NULL,
    name          NVARCHAR(150) NOT NULL,
    cuisine       NVARCHAR(100) NOT NULL DEFAULT '',
    category      NVARCHAR(100) NOT NULL DEFAULT '',
    location      NVARCHAR(200) NOT NULL DEFAULT '',
    contact       NVARCHAR(100) NOT NULL DEFAULT '',
    status        NVARCHAR(20)  NOT NULL DEFAULT 'pending',
    rating        DECIMAL(3,2)  NOT NULL DEFAULT 0.00,
    is_deleted    BIT           NOT NULL DEFAULT 0,
    created_at    DATETIME      NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Restaurants_Owner   FOREIGN KEY (owner_id) REFERENCES Users(user_id),
    CONSTRAINT CK_Restaurants_Status  CHECK (status IN ('active','inactive','pending')),
    CONSTRAINT CK_Restaurants_Rating  CHECK (rating BETWEEN 0 AND 5)
);
GO

-- ============================================================
--  3. Menu_Items
-- ============================================================
IF OBJECT_ID('Menu_Items','U') IS NULL
CREATE TABLE Menu_Items (
    item_id       INT            IDENTITY(1,1) PRIMARY KEY,
    restaurant_id INT            NOT NULL,
    name          NVARCHAR(200)  NOT NULL,
    description   NVARCHAR(500)  NOT NULL DEFAULT '',
    price         DECIMAL(10,2)  NOT NULL,
    category      NVARCHAR(100)  NOT NULL DEFAULT '',
    image_url     NVARCHAR(500)  NOT NULL DEFAULT '',
    availability  BIT            NOT NULL DEFAULT 1,
    is_deleted    BIT            NOT NULL DEFAULT 0,
    created_at    DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_MenuItems_Restaurant FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
    CONSTRAINT CK_MenuItems_Price      CHECK (price >= 0)
);
GO

-- ============================================================
--  4. Orders
-- ============================================================
IF OBJECT_ID('Orders','U') IS NULL
CREATE TABLE Orders (
    order_id       NVARCHAR(50)   NOT NULL PRIMARY KEY,
    user_id        INT            NULL,
    customer_email NVARCHAR(150)  NOT NULL DEFAULT '',
    customer_name  NVARCHAR(100)  NOT NULL DEFAULT '',
    restaurant     NVARCHAR(150)  NOT NULL DEFAULT '',
    restaurant_id  INT            NULL,
    address        NVARCHAR(300)  NOT NULL DEFAULT '',
    subtotal       DECIMAL(10,2)  NOT NULL DEFAULT 0,
    delivery_fee   DECIMAL(10,2)  NOT NULL DEFAULT 0,
    total          DECIMAL(10,2)  NOT NULL DEFAULT 0,
    status         NVARCHAR(30)   NOT NULL DEFAULT 'pending',
    status_step    INT            NOT NULL DEFAULT 1,
    delivery_type  NVARCHAR(20)   NOT NULL DEFAULT 'Delivery',
    rider          NVARCHAR(100)  NOT NULL DEFAULT '',
    reviewed       BIT            NOT NULL DEFAULT 0,
    order_date     DATE           NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    placed_at      DATETIME       NOT NULL DEFAULT GETDATE(),
    delivered_at   DATETIME       NULL,
    CONSTRAINT FK_Orders_User       FOREIGN KEY (user_id)       REFERENCES Users(user_id),
    CONSTRAINT FK_Orders_Restaurant FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
    CONSTRAINT CK_Orders_Status     CHECK (status IN ('pending','accepted','preparing','out for delivery','ready for pickup','delivered','cancelled')),
    CONSTRAINT CK_Orders_Step       CHECK (status_step BETWEEN 0 AND 5),
    CONSTRAINT CK_Orders_Total      CHECK (total >= 0)
);
GO

-- ============================================================
--  5. Order_Items
-- ============================================================
IF OBJECT_ID('Order_Items','U') IS NULL
CREATE TABLE Order_Items (
    order_item_id INT           IDENTITY(1,1) PRIMARY KEY,
    order_id      NVARCHAR(50)  NOT NULL,
    item_id       INT           NULL,
    item_name     NVARCHAR(200) NOT NULL DEFAULT '',
    quantity      INT           NOT NULL DEFAULT 1,
    unit_price    DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_OrderItems_Order FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    CONSTRAINT CK_OrderItems_Qty   CHECK (quantity > 0),
    CONSTRAINT CK_OrderItems_Price CHECK (unit_price >= 0)
);
GO

-- ============================================================
--  6. Payments
-- ============================================================
IF OBJECT_ID('Payments','U') IS NULL
CREATE TABLE Payments (
    payment_id     INT           IDENTITY(1,1) PRIMARY KEY,
    order_id       NVARCHAR(50)  NOT NULL UNIQUE,
    method         NVARCHAR(30)  NOT NULL DEFAULT 'cash',
    payment_meta   NVARCHAR(200) NOT NULL DEFAULT '',
    payment_status NVARCHAR(20)  NOT NULL DEFAULT 'paid',
    paid_at        DATETIME      NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Payments_Order  FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    CONSTRAINT CK_Payments_Method CHECK (method IN ('cash','card','wallet')),
    CONSTRAINT CK_Payments_Status CHECK (payment_status IN ('paid','pending','refunded','failed'))
);
GO

-- ============================================================
--  7. Delivery
-- ============================================================
IF OBJECT_ID('Delivery','U') IS NULL
CREATE TABLE Delivery (
    delivery_id     INT           IDENTITY(1,1) PRIMARY KEY,
    order_id        NVARCHAR(50)  NOT NULL UNIQUE,
    rider_name      NVARCHAR(100) NOT NULL DEFAULT '',
    delivery_status NVARCHAR(30)  NOT NULL DEFAULT 'pending',
    assigned_at     DATETIME      NOT NULL DEFAULT GETDATE(),
    delivered_at    DATETIME      NULL,
    CONSTRAINT FK_Delivery_Order  FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    CONSTRAINT CK_Delivery_Status CHECK (delivery_status IN ('pending','assigned','preparing','out for delivery','delivered','cancelled'))
);
GO

-- ============================================================
--  8. Reviews
-- ============================================================
IF OBJECT_ID('Reviews','U') IS NULL
CREATE TABLE Reviews (
    review_id      INT           IDENTITY(1,1) PRIMARY KEY,
    order_id       NVARCHAR(50)  NULL,
    user_id        INT           NULL,
    restaurant_id  INT           NULL,
    customer_email NVARCHAR(150) NOT NULL DEFAULT '',
    restaurant     NVARCHAR(150) NOT NULL DEFAULT '',
    rating         INT           NOT NULL,
    comment        NVARCHAR(MAX) NOT NULL,
    created_at     DATETIME      NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Reviews_Order      FOREIGN KEY (order_id)      REFERENCES Orders(order_id),
    CONSTRAINT FK_Reviews_User       FOREIGN KEY (user_id)       REFERENCES Users(user_id),
    CONSTRAINT FK_Reviews_Restaurant FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
    CONSTRAINT CK_Reviews_Rating     CHECK (rating BETWEEN 1 AND 5)
);
GO

-- ============================================================
--  9. Riders
-- ============================================================
IF OBJECT_ID('Riders','U') IS NULL
CREATE TABLE Riders (
    rider_id     INT           IDENTITY(1,1) PRIMARY KEY,
    name         NVARCHAR(100) NOT NULL,
    phone        NVARCHAR(30)  NOT NULL DEFAULT '',
    vehicle      NVARCHAR(50)  NOT NULL DEFAULT 'Bike',
    zone         NVARCHAR(80)  NOT NULL DEFAULT 'General',
    rating       DECIMAL(3,2)  NOT NULL DEFAULT 5.00,
    is_available BIT           NOT NULL DEFAULT 1,
    created_at   DATETIME      NOT NULL DEFAULT GETDATE()
);
GO

-- ============================================================
--  Sample seed data
-- ============================================================
-- Admin user (password: admin123)
IF NOT EXISTS (SELECT 1 FROM Users WHERE email='admin@savoria.com')
INSERT INTO Users (name, email, phone, address, password, role)
VALUES ('Admin', 'admin@savoria.com', '0300-0000000', 'Head Office',
        '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', 'admin');
GO

-- Sample restaurant
IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='Savoria Kitchen')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('Savoria Kitchen','Pakistani','Fast Food','Lahore, DHA','0300-1234567','active', 4.50);
GO

-- Sample menu items
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Chicken Biryani')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category, availability)
VALUES
    (1,'Chicken Biryani','Aromatic basmati rice with tender chicken',350.00,'Rice',1),
    (1,'Beef Burger','Juicy beef patty with fresh veggies',280.00,'Burgers',1),
    (1,'Seekh Kebab','Grilled minced meat kebabs (6 pcs)',220.00,'BBQ',1),
    (1,'Mango Shake','Fresh mango blended with milk',120.00,'Drinks',1),
    (1,'Garlic Naan','Soft naan with garlic butter',60.00,'Bread',1);
GO

PRINT 'Savoria DB created successfully!';
GO

-- ============================================================
--  Extended Seed Data — Multiple Restaurants & Menus
-- ============================================================

-- Additional restaurants
IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='Beijing Palace')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('Beijing Palace','Chinese','Fine Dining','Islamabad, F-7','0300-2345678','active', 4.30);
GO

IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='Pizza Roma')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('Pizza Roma','Italian','Fast Food','Rawalpindi, Saddar','0300-3456789','active', 4.60);
GO

IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='Burger Barn')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('Burger Barn','American','Fast Food','Islamabad, G-9','0300-4567890','active', 4.20);
GO

IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='Desi Dhaba')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('Desi Dhaba','Pakistani','Street Food','Rawalpindi, Raja Bazaar','0300-5678901','active', 4.40);
GO

IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='The Grill House')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('The Grill House','BBQ','BBQ & Grill','Islamabad, Blue Area','0300-6789012','active', 4.70);
GO

IF NOT EXISTS (SELECT 1 FROM Restaurants WHERE name='Sweet Cravings')
INSERT INTO Restaurants (name, cuisine, category, location, contact, status, rating)
VALUES ('Sweet Cravings','Desserts','Bakery & Desserts','Islamabad, F-10','0300-7890123','active', 4.50);
GO

-- ── Beijing Palace menu (restaurant_id = 2)
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Kung Pao Chicken')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category)
VALUES
  (2,'Kung Pao Chicken','Spicy stir-fried chicken with peanuts & dried chillies',480.00,'Main Course'),
  (2,'Beef Chow Mein','Stir-fried noodles with tender beef strips',420.00,'Noodles'),
  (2,'Vegetable Fried Rice','Wok-tossed rice with seasonal vegetables',320.00,'Rice'),
  (2,'Spring Rolls (4 pcs)','Crispy rolls stuffed with cabbage and carrots',200.00,'Starters'),
  (2,'Hot & Sour Soup','Classic tangy soup with egg drops and mushrooms',180.00,'Soups'),
  (2,'Szechuan Prawns','Prawns in fiery Szechuan sauce',550.00,'Seafood'),
  (2,'Lychee Juice','Chilled lychee drink',120.00,'Drinks');
GO

-- ── Pizza Roma menu (restaurant_id = 3)
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Margherita Pizza')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category)
VALUES
  (3,'Margherita Pizza','Classic tomato base with mozzarella and basil',650.00,'Pizza'),
  (3,'Pepperoni Pizza','Loaded with spicy pepperoni slices',780.00,'Pizza'),
  (3,'BBQ Chicken Pizza','Smoky BBQ sauce, grilled chicken, red onions',820.00,'Pizza'),
  (3,'Veggie Supreme','Bell peppers, olives, mushrooms on tomato base',700.00,'Pizza'),
  (3,'Garlic Bread (6 pcs)','Toasted baguette with garlic butter',220.00,'Sides'),
  (3,'Pasta Arrabiata','Penne in spicy tomato sauce',480.00,'Pasta'),
  (3,'Tiramisu','Classic Italian coffee-cream dessert',380.00,'Desserts'),
  (3,'Fresh Lemonade','House-squeezed lemon with mint',150.00,'Drinks');
GO

-- ── Burger Barn menu (restaurant_id = 4)
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Classic Smash Burger')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category)
VALUES
  (4,'Classic Smash Burger','Double smashed patty with special sauce',550.00,'Burgers'),
  (4,'Crispy Chicken Burger','Fried chicken breast with coleslaw',480.00,'Burgers'),
  (4,'Mushroom Swiss Burger','Beef patty topped with sautéed mushrooms',580.00,'Burgers'),
  (4,'BBQ Bacon Burger','Beef patty with crispy bacon & BBQ sauce',620.00,'Burgers'),
  (4,'Loaded Fries','Thick-cut fries with cheese sauce and jalapeños',280.00,'Sides'),
  (4,'Onion Rings (8 pcs)','Golden crispy onion rings',220.00,'Sides'),
  (4,'Chocolate Milkshake','Thick shake with whipped cream',250.00,'Drinks'),
  (4,'Strawberry Milkshake','Fresh strawberry blended milkshake',250.00,'Drinks');
GO

-- ── Desi Dhaba menu (restaurant_id = 5)
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Karahi Gosht')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category)
VALUES
  (5,'Karahi Gosht','Slow-cooked mutton karahi with tomatoes & spices',950.00,'Main Course'),
  (5,'Chicken Karahi','Tender chicken in rich spiced gravy',680.00,'Main Course'),
  (5,'Daal Makhani','Creamy black lentils simmered overnight',280.00,'Lentils'),
  (5,'Palak Paneer','Spinach and cottage cheese curry',320.00,'Vegetarian'),
  (5,'Tandoori Naan','Clay-oven baked naan bread',60.00,'Bread'),
  (5,'Laccha Paratha','Layered buttery paratha',70.00,'Bread'),
  (5,'Lassi (Sweet)','Chilled sweet yoghurt drink',120.00,'Drinks'),
  (5,'Gulab Jamun (4 pcs)','Soft milk-solid dumplings in sugar syrup',160.00,'Desserts');
GO

-- ── The Grill House menu (restaurant_id = 6)
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Mixed Grill Platter')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category)
VALUES
  (6,'Mixed Grill Platter','Seekh kebab, chicken tikka, shami kebab & boti',1200.00,'Platters'),
  (6,'Chicken Tikka (6 pcs)','Marinated chicken chunks grilled in clay oven',550.00,'BBQ'),
  (6,'Seekh Kebab (4 pcs)','Spiced minced beef on skewers',380.00,'BBQ'),
  (6,'Mutton Boti (6 pcs)','Tender mutton cubes marinated overnight',620.00,'BBQ'),
  (6,'Grilled Fish','Whole fish marinated in herbs and lemon',750.00,'Seafood'),
  (6,'Raita','Yoghurt with mint and cucumber',80.00,'Sides'),
  (6,'Soft Drink','Chilled canned beverage',80.00,'Drinks');
GO

-- ── Sweet Cravings menu (restaurant_id = 7)
IF NOT EXISTS (SELECT 1 FROM Menu_Items WHERE name='Chocolate Lava Cake')
INSERT INTO Menu_Items (restaurant_id, name, description, price, category)
VALUES
  (7,'Chocolate Lava Cake','Warm chocolate cake with molten centre',350.00,'Cakes'),
  (7,'Red Velvet Slice','Classic red velvet with cream cheese frosting',320.00,'Cakes'),
  (7,'Oreo Cheesecake','Creamy cheesecake on Oreo crust',380.00,'Cakes'),
  (7,'Cinnamon Roll','Freshly baked roll with cream cheese glaze',220.00,'Bakery'),
  (7,'Croissant','Buttery flaky French croissant',180.00,'Bakery'),
  (7,'Nutella Waffle','Belgian waffle drizzled with Nutella',280.00,'Waffles'),
  (7,'Fruit Trifle','Layers of sponge, custard and fresh fruit',260.00,'Desserts'),
  (7,'Hot Chocolate','Rich dark chocolate drink',200.00,'Drinks'),
  (7,'Iced Coffee','Cold brew with milk and caramel',220.00,'Drinks');
GO

PRINT 'Extended seed data inserted successfully!';
GO
