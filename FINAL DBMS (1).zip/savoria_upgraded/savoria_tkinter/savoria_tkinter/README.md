# Savoria — Python Desktop App
### Converted from PHP/MySQL → Python + Tkinter + SQL Server

---

## Stack

| Tool | Purpose |
|---|---|
| Python 3.9+ | Programming language |
| Tkinter | Desktop GUI (built into Python) |
| VS Code | Code editor |
| pyodbc | Connect Python to SQL Server |
| bcrypt | Password hashing |
| SQL Server | Database (managed via SSMS) |

---

## Project Structure

```
savoria_tkinter/
│
├── main.py                  ← Run this to start the app
├── db.py                    ← SQL Server connection (edit SERVER here)
├── auth.py                  ← Login, register, user management
├── models.py                ← All business logic (restaurants, orders, etc.)
│
├── windows/
│   ├── login_window.py      ← Login + Register screen
│   ├── customer_window.py   ← Customer: browse, cart, order, track
│   ├── admin_window.py      ← Admin: dashboard, orders, users, riders
│   └── owner_window.py      ← Restaurant owner: menu management
│
└── sql/
    └── create_tables.sql    ← Run this in SSMS FIRST
```

---

## Setup Steps

### Step 1 — Install Python & VS Code
- Download Python 3.9+: https://python.org
- Download VS Code: https://code.visualstudio.com
- Install Python extension in VS Code

### Step 2 — Install SQL Server & SSMS
- Download SQL Server Express (free): https://www.microsoft.com/sql-server
- Download SSMS: https://aka.ms/ssmsfullsetup

### Step 3 — Create the Database in SSMS
1. Open SSMS → connect to your server
2. Click "New Query"
3. Open `sql/create_tables.sql` → paste it → press **F5** (Execute)
4. You should see: `Savoria DB created successfully!`

### Step 4 — Install Python Libraries
```bash
pip install pyodbc bcrypt
```

Also install the ODBC Driver 17 for SQL Server:
https://learn.microsoft.com/sql/connect/odbc/download-odbc-driver-for-sql-server

### Step 5 — Configure DB Connection
Open `db.py` and set your server name:
```python
SERVER   = r'localhost\SQLEXPRESS'   # Your SSMS server name
DATABASE = 'savoria_db'
USE_WINDOWS_AUTH = True              # True = Windows Auth (recommended)
```

To find your server name: open SSMS → the server name shown in the connect dialog.

### Step 6 — Run the App
```bash
python main.py
```

---

## Default Login

| Email | Password | Role |
|---|---|---|
| admin@savoria.com | admin123 | Admin |

---

## Features

### Customer
- Browse active restaurants
- Filter menu by category
- Add items to cart, set quantity
- Choose Delivery or Pickup
- Choose payment method (Cash/Card/Wallet)
- Place orders
- Track order status
- View order history

### Restaurant Owner
- Register your restaurant (pending admin approval)
- Add / remove / toggle menu items
- View incoming orders
- Update order status (accepted → preparing → delivered)

### Admin
- Dashboard with KPI stats (orders, revenue, users)
- View and update all orders
- Approve / deactivate restaurants
- Manage all users
- Manage delivery riders
- Add / remove riders

---

## Troubleshooting

**"Could not connect to SQL Server"**
- Make sure SQL Server service is running (search "Services" in Windows)
- Check your server name in `db.py` matches what SSMS shows
- Try `localhost` or `.\SQLEXPRESS` or `(localdb)\MSSQLLocalDB`

**"No module named pyodbc"**
```bash
pip install pyodbc
```

**"Data source name not found"**
- Install ODBC Driver 17 for SQL Server from Microsoft

**"Login failed"** after running the app
- Make sure you ran `sql/create_tables.sql` in SSMS first
- The sample admin password hash in the SQL uses bcrypt — the default admin password is `admin123`
