# windows/owner_window.py — Savoria Restaurant Owner Portal

import tkinter as tk
from tkinter import ttk, messagebox
import models
import auth

# ── Colour palette ──────────────────────────────────────────────────────────
BG       = "#0D0A14"
SURFACE  = "#160F2A"
INPUT_BG = "#1E1535"
HEADER   = "#2A1650"
GOLD     = "#E8C46A"
GOLD_R   = "#C9A84C"
GOLD_DIM = "#8A6A1F"
MUTED    = "#7A6A9A"
BODY     = "#F0E6FF"
DANGER   = "#ef4444"
SUCCESS  = "#22c55e"
WARN_FG  = "#E8A84C"


def _style_notebook(nb: ttk.Notebook):
    s = ttk.Style()
    s.theme_use("default")
    s.configure("Dark.TNotebook", background=HEADER, borderwidth=0,
                tabmargins=[0, 0, 0, 0])
    s.configure("Dark.TNotebook.Tab", background=SURFACE, foreground=MUTED,
                font=("Georgia", 10), padding=[14, 8], borderwidth=0)
    s.map("Dark.TNotebook.Tab",
          background=[("selected", BG), ("active", INPUT_BG)],
          foreground=[("selected", GOLD), ("active", GOLD_R)])
    nb.configure(style="Dark.TNotebook")


def _style_treeview():
    s = ttk.Style()
    s.configure("Dark.Treeview", background=INPUT_BG, foreground=BODY,
                fieldbackground=INPUT_BG, rowheight=26,
                font=("Segoe UI", 9), borderwidth=0)
    s.configure("Dark.Treeview.Heading", background=SURFACE, foreground=GOLD_R,
                font=("Segoe UI", 9, "bold"), relief="flat")
    s.map("Dark.Treeview",
          background=[("selected", GOLD_DIM)],
          foreground=[("selected", GOLD)])


def _style_combobox():
    s = ttk.Style()
    s.configure("Dark.TCombobox", fieldbackground=INPUT_BG, background=INPUT_BG,
                foreground=BODY, selectbackground=GOLD_DIM, selectforeground=GOLD,
                arrowcolor=GOLD_R, bordercolor=GOLD_DIM,
                lightcolor=GOLD_DIM, darkcolor=GOLD_DIM)
    s.map("Dark.TCombobox",
          fieldbackground=[("readonly", INPUT_BG)],
          foreground=[("readonly", BODY)])


def _btn(parent, text, command, bg=GOLD_R, fg=BG, **kw):
    return tk.Button(parent, text=text, command=command,
                     bg=bg, fg=fg, font=("Segoe UI", 9, "bold"),
                     relief="flat", cursor="hand2",
                     activebackground=GOLD, activeforeground=BG, **kw)


def _label(parent, text, size=10, color=BODY, bold=False, **kw):
    weight = "bold" if bold else "normal"
    return tk.Label(parent, text=text, font=("Georgia", size, weight),
                    fg=color, bg=kw.pop("bg", BG), **kw)


def _entry(parent, textvariable, width=None, show=""):
    e = tk.Entry(parent, textvariable=textvariable,
                 bg=INPUT_BG, fg=BODY, insertbackground=GOLD,
                 selectbackground=GOLD_DIM, selectforeground=GOLD,
                 relief="flat", highlightthickness=1,
                 highlightbackground=GOLD_DIM, highlightcolor=GOLD_R,
                 font=("Segoe UI", 10), show=show)
    if width:
        e.configure(width=width)
    return e


class OwnerWindow(tk.Toplevel):
    def __init__(self, master, user):
        super().__init__(master)
        self.user       = user
        self.restaurant = None

        self.title(f"Savoria — Owner Portal ({user['name']})")
        self.configure(bg=BG)

        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        w  = max(900, int(sw * 0.80))
        h  = max(620, int(sh * 0.82))
        x  = (sw - w) // 2
        y  = (sh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.minsize(880, 600)

        _style_treeview()
        _style_combobox()

        self._load_restaurant()
        self._build_ui()

    # ── helpers ──────────────────────────────────────────────────────────────
    def _load_restaurant(self):
        self.restaurant = models.get_owner_restaurant(self.user['user_id'])

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to log out?",
                               parent=self):
            self.destroy()
            self.master.deiconify()

    # ── top navbar ────────────────────────────────────────────────────────────
    def _build_ui(self):
        nav = tk.Frame(self, bg=HEADER, height=52)
        nav.pack(fill="x")
        nav.pack_propagate(False)

        tk.Label(nav, text="🍽  Savoria — Owner Portal",
                 font=("Georgia", 15, "bold"),
                 fg=GOLD, bg=HEADER).pack(side="left", padx=18, pady=8)

        tk.Button(nav, text="⏻  Logout", command=self._logout,
                  bg=HEADER, fg=MUTED, font=("Segoe UI", 9),
                  relief="flat", cursor="hand2",
                  activebackground=SURFACE, activeforeground=DANGER,
                  bd=0, padx=10).pack(side="right", padx=(0, 8))

        tk.Frame(nav, bg=GOLD_DIM, width=1).pack(side="right", fill="y", pady=12)

        if self.restaurant:
            tk.Label(nav, text=f"🏪  {self.restaurant['name']}",
                     font=("Segoe UI", 10), fg=GOLD_R, bg=HEADER
                     ).pack(side="right", padx=18)
        else:
            tk.Label(nav, text="No restaurant assigned",
                     font=("Segoe UI", 10), fg=MUTED, bg=HEADER
                     ).pack(side="right", padx=18)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True)
        _style_notebook(self.nb)

        if not self.restaurant:
            self._tab_register_restaurant()
        else:
            self._tab_menu()
            self._tab_orders()
            self._tab_sales()          # ← Sales Report

        self._tab_change_password()    # always available

    # ══ REGISTER RESTAURANT ══════════════════════════════════════════════════
    def _tab_register_restaurant(self):
        outer = tk.Frame(self.nb, bg=BG)
        self.nb.add(outer, text="  Register Restaurant  ")

        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
        vsb    = tk.Scrollbar(outer, orient="vertical", command=canvas.yview,
                              bg=SURFACE, troughcolor=BG)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        win   = canvas.create_window((0, 0), window=inner, anchor="nw")

        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        card = tk.Frame(inner, bg=SURFACE,
                        highlightthickness=1, highlightbackground=GOLD_DIM)
        card.pack(padx=60, pady=40, fill="x")

        pad = tk.Frame(card, bg=SURFACE)
        pad.pack(fill="both", padx=28, pady=24)

        tk.Label(pad, text="Register Your Restaurant",
                 font=("Georgia", 17, "bold"), fg=GOLD, bg=SURFACE).pack(anchor="w")
        tk.Label(pad,
                 text="Your listing will be reviewed by an admin before going live.",
                 font=("Segoe UI", 9), fg=MUTED, bg=SURFACE
                 ).pack(anchor="w", pady=(2, 12))
        tk.Frame(pad, bg=GOLD_DIM, height=1).pack(fill="x", pady=(0, 16))

        fields = {}

        def _field(parent, label, row, col, colspan=1):
            f = tk.Frame(parent, bg=SURFACE)
            f.grid(row=row, column=col, columnspan=colspan,
                   sticky="ew", padx=(0, 12 if col == 0 else 0), pady=6)
            tk.Label(f, text=label, font=("Segoe UI", 9, "bold"),
                     fg=GOLD_R, bg=SURFACE).pack(anchor="w")
            var = tk.StringVar()
            _entry(f, var).pack(fill="x", ipady=6, pady=(3, 0))
            fields[label] = var

        grid = tk.Frame(pad, bg=SURFACE)
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        _field(grid, "Restaurant Name", 0, 0, colspan=2)
        _field(grid, "Cuisine Type",    1, 0)
        _field(grid, "Category",        1, 1)
        _field(grid, "Location",        2, 0, colspan=2)
        _field(grid, "Contact",         3, 0, colspan=2)

        tk.Frame(pad, bg=GOLD_DIM, height=1).pack(fill="x", pady=(16, 0))

        def register():
            models.add_restaurant(
                self.user['user_id'],
                fields["Restaurant Name"].get(),
                fields["Cuisine Type"].get(),
                fields["Category"].get(),
                fields["Location"].get(),
                fields["Contact"].get()
            )
            messagebox.showinfo(
                "Submitted",
                "Your restaurant has been submitted for admin approval.\n"
                "Once approved (status: active), you can manage your menu.",
                parent=self
            )
            self._load_restaurant()

        _btn(pad, "  Submit for Approval  ", register,
             padx=20, pady=10).pack(anchor="e", pady=(16, 0))

        notice = tk.Frame(pad, bg="#1E1535",
                          highlightthickness=1, highlightbackground=GOLD_DIM)
        notice.pack(fill="x", pady=(14, 0))
        tk.Label(notice,
                 text="ℹ  After submission an admin will review your listing. "
                      "Once status is active you can manage your menu and orders.",
                 font=("Segoe UI", 9), fg=MUTED, bg="#1E1535",
                 wraplength=560, justify="left"
                 ).pack(padx=14, pady=10, anchor="w")

    # ══ MENU MANAGEMENT ══════════════════════════════════════════════════════
    def _tab_menu(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  Menu Items  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=14, pady=(12, 4))
        _label(top, "My Menu", size=13, color=GOLD, bold=True, bg=BG).pack(side="left")
        _btn(top, "↻  Refresh", self._load_menu, padx=10).pack(side="right")

        cols = ("ID", "Name", "Category", "Price", "Available")
        self.menu_tree = ttk.Treeview(frame, columns=cols, show="headings",
                                      height=12, style="Dark.Treeview")
        widths  = {"ID": 55, "Name": 230, "Category": 130, "Price": 110, "Available": 90}
        anchors = {"Price": "e", "Available": "center"}
        for c in cols:
            self.menu_tree.heading(c, text=c)
            self.menu_tree.column(c, width=widths[c], anchor=anchors.get(c, "w"))

        sb = tk.Scrollbar(frame, orient="vertical", command=self.menu_tree.yview,
                          bg=SURFACE, troughcolor=BG)
        self.menu_tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", padx=(0, 4))
        self.menu_tree.pack(fill="both", expand=True, padx=14, pady=4)

        act = tk.Frame(frame, bg=BG)
        act.pack(fill="x", padx=14, pady=4)
        _btn(act, "Toggle Availability", self._toggle_item, padx=10).pack(side="left")
        _btn(act, "Delete Item", self._delete_item,
             bg=DANGER, fg="white", padx=10).pack(side="left", padx=8)

        add_f = tk.LabelFrame(frame, text="  Add New Item  ",
                               font=("Segoe UI", 9, "bold"),
                               bg=SURFACE, fg=GOLD_R, bd=1, relief="flat",
                               highlightthickness=1, highlightbackground=GOLD_DIM)
        add_f.pack(fill="x", padx=14, pady=8)

        row = tk.Frame(add_f, bg=SURFACE)
        row.pack(fill="x", padx=12, pady=8)

        item_fields = {}
        specs = [("Name", 22), ("Category", 13), ("Price", 8), ("Description", 24)]
        for lbl, w in specs:
            tk.Label(row, text=lbl + ":", bg=SURFACE,
                     font=("Segoe UI", 9, "bold"), fg=GOLD_R).pack(side="left")
            var = tk.StringVar()
            ent = _entry(row, var, width=w)
            ent.pack(side="left", padx=(2, 12), ipady=4)
            item_fields[lbl] = var

        def add_item():
            try:
                price = float(item_fields["Price"].get())
            except ValueError:
                messagebox.showerror("Error", "Price must be a number.", parent=self)
                return
            models.add_menu_item(
                self.restaurant['restaurant_id'],
                item_fields["Name"].get(),
                item_fields["Description"].get(),
                price,
                item_fields["Category"].get()
            )
            self._load_menu()

        _btn(add_f, "Add Item", add_item, padx=14
             ).pack(anchor="e", padx=12, pady=(0, 8))

        self._load_menu()

    def _load_menu(self):
        if not self.restaurant:
            return
        self.menu_items = models.get_menu_items(self.restaurant['restaurant_id'])
        self.menu_tree.delete(*self.menu_tree.get_children())
        for it in self.menu_items:
            self.menu_tree.insert("", "end", values=(
                it['item_id'], it['name'], it['category'],
                f"Rs. {it['price']:.2f}",
                "Yes" if it['availability'] else "No"
            ))

    def _toggle_item(self):
        sel = self.menu_tree.selection()
        if not sel:
            return
        idx  = self.menu_tree.index(sel[0])
        item = self.menu_items[idx]
        models.update_menu_item(item['item_id'],
                                availability=0 if item['availability'] else 1)
        self._load_menu()

    def _delete_item(self):
        sel = self.menu_tree.selection()
        if not sel:
            return
        idx  = self.menu_tree.index(sel[0])
        item = self.menu_items[idx]
        if messagebox.askyesno("Confirm", f"Delete '{item['name']}'?", parent=self):
            models.delete_menu_item(item['item_id'])
            self._load_menu()

    # ══ INCOMING ORDERS ══════════════════════════════════════════════════════
    def _tab_orders(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  Incoming Orders  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=14, pady=(12, 4))
        _label(top, "Incoming Orders", size=13, color=GOLD, bold=True, bg=BG).pack(side="left")
        _btn(top, "↻  Refresh", self._load_owner_orders, padx=10).pack(side="right")

        cols = ("Order ID", "Customer", "Items", "Total", "Payment", "Status", "Date")
        self.owner_orders_tree = ttk.Treeview(frame, columns=cols,
                                               show="headings", height=14,
                                               style="Dark.Treeview")
        col_cfg = {
            "Order ID": (130, "w"), "Customer": (140, "w"),
            "Items":    (55, "center"), "Total": (100, "e"),
            "Payment":  (110, "w"), "Status": (140, "w"), "Date": (100, "w"),
        }
        for c in cols:
            w, a = col_cfg[c]
            self.owner_orders_tree.heading(c, text=c)
            self.owner_orders_tree.column(c, width=w, anchor=a)

        osb = tk.Scrollbar(frame, orient="vertical",
                           command=self.owner_orders_tree.yview,
                           bg=SURFACE, troughcolor=BG)
        self.owner_orders_tree.configure(yscrollcommand=osb.set)
        osb.pack(side="right", fill="y", padx=(0, 4))
        self.owner_orders_tree.pack(fill="both", expand=True, padx=14, pady=4)

        act = tk.Frame(frame, bg=BG)
        act.pack(fill="x", padx=14, pady=6)
        tk.Label(act, text="Mark selected as:",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")

        self.owner_status_var = tk.StringVar(value="accepted")
        cb = ttk.Combobox(act, textvariable=self.owner_status_var,
                          values=["accepted", "preparing", "ready for pickup",
                                  "out for delivery", "delivered", "cancelled"],
                          state="readonly", width=22, style="Dark.TCombobox")
        cb.pack(side="left", padx=8)
        _btn(act, "Update Status", self._update_owner_order, padx=12).pack(side="left")

        self._load_owner_orders()

    def _load_owner_orders(self):
        if not self.restaurant:
            return
        self.owner_orders = models.get_orders(
            restaurant_id=self.restaurant['restaurant_id'])
        self.owner_orders_tree.delete(*self.owner_orders_tree.get_children())
        for o in self.owner_orders:
            items = models.get_order_items(o['order_id'])
            # ── safe fallback for None payment_method ──────────────────────
            payment = (o.get('payment_method') or 'cash').title()
            self.owner_orders_tree.insert("", "end", values=(
                o['order_id'],
                o.get('customer_name', ''),
                len(items),
                f"Rs. {o['total']:.2f}",
                payment,
                o['status'].title(),
                str(o.get('order_date', ''))[:10],
            ))

    def _update_owner_order(self):
        sel = self.owner_orders_tree.selection()
        if not sel:
            return
        idx   = self.owner_orders_tree.index(sel[0])
        order = self.owner_orders[idx]
        models.update_order_status(order['order_id'], self.owner_status_var.get())
        self._load_owner_orders()

    # ══ SALES REPORT ═════════════════════════════════════════════════════════
    def _tab_sales(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  📊 Sales Report  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=14, pady=(12, 4))
        _label(top, "Sales Report", size=13, color=GOLD, bold=True, bg=BG).pack(side="left")
        _btn(top, "↻  Refresh", self._load_sales, padx=10).pack(side="right")

        # ── KPI cards ────────────────────────────────────────────────────
        kpi_row = tk.Frame(frame, bg=BG)
        kpi_row.pack(fill="x", padx=14, pady=8)

        self._sales_kpis: dict[str, tk.Label] = {}
        kpi_defs = [
            ("total_orders",     "Total Orders",     GOLD),
            ("total_revenue",    "Total Revenue",    "#5DC96A"),
            ("delivered_orders", "Delivered Orders", "#7A9EF0"),
            ("pending_orders",   "Pending/Active",   "#E8A84C"),
        ]
        for key, label, fg in kpi_defs:
            card = tk.Frame(kpi_row, bg=SURFACE,
                            highlightbackground=GOLD_DIM, highlightthickness=1,
                            width=180, height=80)
            card.pack(side="left", padx=6, pady=4)
            card.pack_propagate(False)
            tk.Label(card, text=label, font=("Segoe UI", 9),
                     fg=MUTED, bg=SURFACE).pack(pady=(10, 2))
            val = tk.Label(card, text="—", font=("Georgia", 18, "bold"),
                           fg=fg, bg=SURFACE)
            val.pack()
            self._sales_kpis[key] = val

        tk.Frame(frame, bg=GOLD_DIM, height=1).pack(fill="x", padx=14, pady=4)

        # ── Top selling items ─────────────────────────────────────────────
        _label(frame, "Top Selling Items", size=11, color=GOLD_R, bold=True,
               bg=BG).pack(anchor="w", padx=14, pady=(6, 2))

        cols_top = ("Item Name", "Category", "Units Sold", "Revenue")
        self.top_items_tree = ttk.Treeview(frame, columns=cols_top,
                                            show="headings", height=6,
                                            style="Dark.Treeview")
        top_cfg = {"Item Name": 220, "Category": 130,
                   "Units Sold": 100, "Revenue": 120}
        top_anc = {"Units Sold": "center", "Revenue": "e"}
        for c in cols_top:
            self.top_items_tree.heading(c, text=c)
            self.top_items_tree.column(c, width=top_cfg[c],
                                       anchor=top_anc.get(c, "w"))
        self.top_items_tree.pack(fill="x", padx=14, pady=4)

        tk.Frame(frame, bg=GOLD_DIM, height=1).pack(fill="x", padx=14, pady=4)

        # ── Recent delivered orders ───────────────────────────────────────
        _label(frame, "Recent Delivered Orders", size=11, color=GOLD_R, bold=True,
               bg=BG).pack(anchor="w", padx=14, pady=(6, 2))

        cols_rec = ("Order ID", "Customer", "Total", "Payment", "Date")
        self.recent_orders_tree = ttk.Treeview(frame, columns=cols_rec,
                                                show="headings", height=6,
                                                style="Dark.Treeview")
        rec_cfg = {"Order ID": 140, "Customer": 160,
                   "Total": 110, "Payment": 120, "Date": 110}
        rec_anc = {"Total": "e"}
        for c in cols_rec:
            self.recent_orders_tree.heading(c, text=c)
            self.recent_orders_tree.column(c, width=rec_cfg[c],
                                            anchor=rec_anc.get(c, "w"))

        rsb = tk.Scrollbar(frame, orient="vertical",
                           command=self.recent_orders_tree.yview,
                           bg=SURFACE, troughcolor=BG)
        self.recent_orders_tree.configure(yscrollcommand=rsb.set)
        rsb.pack(side="right", fill="y", padx=(0, 4))
        self.recent_orders_tree.pack(fill="both", expand=True, padx=14, pady=4)

        self._load_sales()

    def _load_sales(self):
        if not self.restaurant:
            return
        rid = self.restaurant['restaurant_id']

        # ── KPIs ─────────────────────────────────────────────────────────
        summary = models.get_restaurant_sales_summary(rid)
        self._sales_kpis["total_orders"].config(
            text=str(summary.get("total_orders", 0)))
        self._sales_kpis["total_revenue"].config(
            text=f"Rs. {summary.get('total_revenue', 0):.0f}")
        self._sales_kpis["delivered_orders"].config(
            text=str(summary.get("delivered_orders", 0)))
        self._sales_kpis["pending_orders"].config(
            text=str(summary.get("pending_orders", 0)))

        # ── Top items ─────────────────────────────────────────────────────
        self.top_items_tree.delete(*self.top_items_tree.get_children())
        for row in models.get_top_menu_items(rid):
            self.top_items_tree.insert("", "end", values=(
                row["name"], row.get("category", ""),
                row["units_sold"], f"Rs. {row['revenue']:.2f}",
            ))

        # ── Recent delivered orders ───────────────────────────────────────
        self.recent_orders_tree.delete(*self.recent_orders_tree.get_children())
        delivered = models.get_orders(restaurant_id=rid, status="delivered")
        for o in delivered[:30]:
            # ── safe fallback for None payment_method ──────────────────────
            payment = (o.get("payment_method") or "cash").title()
            self.recent_orders_tree.insert("", "end", values=(
                o["order_id"], o.get("customer_name", ""),
                f"Rs. {o['total']:.2f}",
                payment,
                str(o.get("order_date", ""))[:10],
            ))

    # ══ CHANGE PASSWORD ═══════════════════════════════════════════════════════
    def _tab_change_password(self):
        outer = tk.Frame(self.nb, bg=BG)
        self.nb.add(outer, text="  🔒 Change Password  ")

        holder = tk.Frame(outer, bg=BG)
        holder.pack(expand=True)

        card = tk.Frame(holder, bg=SURFACE,
                        highlightthickness=1, highlightbackground=GOLD_DIM)
        card.pack(padx=20, pady=20)

        pad = tk.Frame(card, bg=SURFACE)
        pad.pack(padx=36, pady=28)

        tk.Label(pad, text="🔒  Change Password",
                 font=("Georgia", 16, "bold"), fg=GOLD, bg=SURFACE).pack(anchor="w")
        tk.Label(pad, text="Enter your current password, then choose a new one.",
                 font=("Segoe UI", 9), fg=MUTED, bg=SURFACE
                 ).pack(anchor="w", pady=(4, 14))
        tk.Frame(pad, bg=GOLD_DIM, height=1).pack(fill="x", pady=(0, 18))

        pw_vars: dict[str, tk.StringVar] = {}

        def _pw_field(label_text: str, key: str):
            row = tk.Frame(pad, bg=SURFACE)
            row.pack(fill="x", pady=6)
            tk.Label(row, text=label_text, font=("Segoe UI", 9, "bold"),
                     fg=GOLD_R, bg=SURFACE, width=20, anchor="w").pack(side="left")
            var = tk.StringVar()
            pw_vars[key] = var
            ef = tk.Frame(row, bg=INPUT_BG, highlightthickness=1,
                          highlightbackground=GOLD_DIM, highlightcolor=GOLD_R)
            ef.pack(side="left")
            ent = tk.Entry(ef, textvariable=var, show="●",
                           bg=INPUT_BG, fg=BODY, insertbackground=GOLD,
                           selectbackground=GOLD_DIM, selectforeground=GOLD,
                           relief="flat", font=("Segoe UI", 10), width=28, bd=6)
            ent.pack(side="left")

            eye_var = tk.BooleanVar(value=False)
            btn_ref = [None]

            def _toggle(e=ent, v=eye_var, ref=btn_ref):
                v.set(not v.get())
                e.configure(show="" if v.get() else "●")
                ref[0].configure(text="🙈" if v.get() else "👁")

            eye_btn = tk.Button(ef, text="👁", command=_toggle,
                                bg=INPUT_BG, fg=MUTED, relief="flat",
                                cursor="hand2", font=("Segoe UI", 10),
                                activebackground=INPUT_BG,
                                activeforeground=GOLD_R, bd=0, padx=4)
            eye_btn.pack(side="left", padx=(0, 2))
            btn_ref[0] = eye_btn

        _pw_field("Current Password", "current")
        _pw_field("New Password",     "new")
        _pw_field("Confirm Password", "confirm")

        tk.Frame(pad, bg=GOLD_DIM, height=1).pack(fill="x", pady=(20, 0))

        status_lbl = tk.Label(pad, text="", font=("Segoe UI", 9),
                              bg=SURFACE, fg=SUCCESS)
        status_lbl.pack(anchor="w", pady=(8, 0))

        def _do_change():
            cur     = pw_vars["current"].get()
            new     = pw_vars["new"].get()
            confirm = pw_vars["confirm"].get()
            if not cur or not new or not confirm:
                status_lbl.config(text="⚠  All fields are required.", fg=WARN_FG)
                return
            if new != confirm:
                status_lbl.config(text="⚠  New passwords do not match.", fg=WARN_FG)
                return
            if len(new) < 6:
                status_lbl.config(
                    text="⚠  Password must be at least 6 characters.", fg=WARN_FG)
                return
            if not auth.verify_password(self.user['email'], cur):
                status_lbl.config(text="✖  Current password is incorrect.", fg=DANGER)
                return
            auth.change_password(self.user['email'], new)
            for v in pw_vars.values():
                v.set("")
            status_lbl.config(text="✔  Password changed successfully!", fg=SUCCESS)

        _btn(pad, "  Update Password  ", _do_change,
             padx=20, pady=10).pack(anchor="e", pady=(12, 0))