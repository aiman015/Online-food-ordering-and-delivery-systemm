# windows/admin_window.py — Savoria Admin Dashboard

import tkinter as tk
from tkinter import ttk, messagebox
import models
import auth

# ── Palette ────────────────────────────────────────────────────────────────
BG         = "#0D0A14"
CARD       = "#160F2A"
INPUT      = "#1E1535"
HEADER     = "#2A1650"
GOLD       = "#E8C46A"
GOLD2      = "#C9A84C"
GOLD3      = "#8A6A1F"
TEXT       = "#EDE8D6"
MUTED      = "#7A6E8A"
BORDER     = "#2E1F54"
DANGER     = "#7D3A3A"
SUCCESS    = "#1A3A1E"
SUCCESS_FG = "#5DC96A"
WARN       = "#3A2A10"
WARN_FG    = "#E8A84C"
INFO       = "#1A1F40"
INFO_FG    = "#7A9EF0"
DANGER_FG  = "#ef4444"


class AdminWindow(tk.Toplevel):
    def __init__(self, master, user: dict):
        super().__init__(master)
        self.user = user
        self.title("Savoria — Admin Dashboard")
        self.geometry("1200x750")
        self.configure(bg=BG)
        self._apply_styles()
        self._build_ui()
        self._center()

    def _center(self):
        self.update_idletasks()
        x = max(0, (self.winfo_screenwidth()  - 1200) // 2)
        y = max(0, (self.winfo_screenheight() - 750)  // 2)
        self.geometry(f"1200x750+{x}+{y}")

    def _apply_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=CARD, borderwidth=0)
        style.configure("TNotebook.Tab",
                         font=("Segoe UI", 11), padding=[14, 6],
                         background=CARD, foreground=MUTED)
        style.map("TNotebook.Tab",
                  background=[("selected", BG)],
                  foreground=[("selected", GOLD)])
        style.configure("Treeview",
                         background=CARD, foreground=TEXT,
                         fieldbackground=CARD, rowheight=26, borderwidth=0)
        style.configure("Treeview.Heading",
                         background=HEADER, foreground=GOLD2, relief="flat",
                         font=("Segoe UI", 10, "bold"))
        style.map("Treeview",
                  background=[("selected", GOLD3)],
                  foreground=[("selected", TEXT)])
        style.configure("TCombobox",
                         fieldbackground=INPUT, background=INPUT,
                         foreground=TEXT, selectbackground=GOLD3,
                         selectforeground=TEXT, arrowcolor=GOLD2)
        style.map("TCombobox",
                  fieldbackground=[("readonly", INPUT)],
                  foreground=[("readonly", TEXT)])
        style.configure("TSeparator", background=BORDER)

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?",
                                parent=self):
            self.destroy()
            self.master.destroy()

    def _build_ui(self):
        nav = tk.Frame(self, bg=HEADER, height=55)
        nav.pack(fill="x")
        nav.pack_propagate(False)
        tk.Label(nav, text="🍽  Savoria Admin",
                 font=("Georgia", 18, "bold"),
                 fg=GOLD, bg=HEADER).pack(side="left", padx=20)
        tk.Button(nav, text="⇢ Logout", command=self._logout,
                  bg=DANGER, fg=TEXT, font=("Segoe UI", 10, "bold"),
                  relief="flat", cursor="hand2",
                  padx=12, pady=4).pack(side="right", padx=16, pady=10)
        tk.Label(nav, text=f"🔑 {self.user['name']}  |  Admin",
                 font=("Segoe UI", 11), fg=GOLD2, bg=HEADER).pack(side="right", padx=8)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True)

        self._tab_dashboard()
        self._tab_orders()
        self._tab_restaurants()
        self._tab_users()
        self._tab_riders()
        self._tab_reviews()          # ← NEW
        self._tab_reports()          # ← NEW
        self._tab_change_password()

    # ── shared helpers ──────────────────────────────────────────────────────
    def _section_label(self, parent: tk.Frame, text: str):
        tk.Label(parent, text=text,
                 font=("Georgia", 13, "bold"),
                 fg=GOLD, bg=BG).pack(anchor="w", padx=20, pady=(10, 4))

    def _action_btn(self, parent, text: str, cmd, color=GOLD3) -> tk.Button:
        return tk.Button(parent, text=text, command=cmd,
                         bg=color, fg=TEXT,
                         font=("Segoe UI", 9, "bold"),
                         relief="flat", cursor="hand2", padx=10)

    def _build_tree(self, parent: tk.Frame, cols: tuple,
                    widths: list, height: int = 16,
                    anchors: dict | None = None) -> ttk.Treeview:
        anchors = anchors or {}
        frame = tk.Frame(parent, bg=BG)
        frame.pack(fill="both", expand=True, padx=10, pady=4)
        tree = ttk.Treeview(frame, columns=cols, show="headings", height=height)
        vsb  = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)
        for c, w in zip(cols, widths):
            tree.heading(c, text=c)
            tree.column(c, width=w, anchor=anchors.get(c, "w"))
        return tree

    # ══════════════════════════════════════════════════════════════════════
    # TAB 1 — DASHBOARD
    # ══════════════════════════════════════════════════════════════════════
    def _tab_dashboard(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  📊 Dashboard  ")

        tk.Label(frame, text="Overview",
                 font=("Georgia", 16, "bold"),
                 fg=GOLD, bg=BG).pack(anchor="w", padx=20, pady=15)

        kpi_row = tk.Frame(frame, bg=BG)
        kpi_row.pack(fill="x", padx=20, pady=5)

        self.kpi_frames: dict[str, tk.Label] = {}
        kpis = [
            ("Total Orders",   "total_orders",   GOLD,       "📦"),
            ("Revenue (Rs.)",  "total_revenue",  SUCCESS_FG, "💰"),
            ("Total Users",    "total_users",    INFO_FG,    "👥"),
            ("Pending Orders", "pending_orders", WARN_FG,    "🕐"),
        ]
        kpi_colors = [CARD, SUCCESS, INFO, WARN]
        for (lbl, key, fg, icon), bg_col in zip(kpis, kpi_colors):
            card = tk.Frame(kpi_row, bg=bg_col, width=220, height=100,
                            highlightbackground=BORDER, highlightthickness=1)
            card.pack(side="left", padx=8, pady=4)
            card.pack_propagate(False)
            tk.Label(card, text=f"{icon}  {lbl}",
                     font=("Segoe UI", 10), fg=MUTED, bg=bg_col).pack(pady=(14, 2))
            val_lbl = tk.Label(card, text="—",
                               font=("Georgia", 22, "bold"), fg=fg, bg=bg_col)
            val_lbl.pack()
            self.kpi_frames[key] = val_lbl

        self._action_btn(frame, "↻ Refresh Stats", self._load_stats).pack(
            anchor="w", padx=20, pady=10)

        self._section_label(frame, "Recent Orders")
        cols   = ("Order ID", "Customer", "Restaurant", "Total", "Status", "Date")
        widths = [120, 140, 160, 90, 130, 100]
        self.dash_tree = self._build_tree(frame, cols, widths, height=10,
                                           anchors={"Total": "e"})
        self._load_stats()

    def _load_stats(self):
        summary = models.get_summary()
        for k, lbl in self.kpi_frames.items():
            val = summary.get(k, 0)
            lbl.config(text=f"{val:,.0f}" if isinstance(val, float) else str(val))

        orders = models.get_all_orders()[:20]
        self.dash_tree.delete(*self.dash_tree.get_children())
        for o in orders:
            self.dash_tree.insert("", "end", values=(
                o["order_id"],
                o.get("customer_name", ""),
                o.get("restaurant_name") or o.get("restaurant", ""),
                f"Rs. {o['total']:.2f}",
                o["status"].title(),
                str(o["order_date"])[:10],
            ))

    # ══════════════════════════════════════════════════════════════════════
    # TAB 2 — ALL ORDERS
    # ══════════════════════════════════════════════════════════════════════
    def _tab_orders(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  📦 Orders  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="All Orders",
                 font=("Georgia", 14, "bold"), fg=GOLD, bg=BG).pack(side="left")

        self.ord_status_var = tk.StringVar(value="All")
        status_combo = ttk.Combobox(
            top, textvariable=self.ord_status_var,
            values=["All", "pending", "accepted", "preparing",
                    "out for delivery", "delivered", "cancelled"],
            state="readonly", width=18)
        status_combo.pack(side="right", padx=4)
        tk.Label(top, text="Filter:", bg=BG, fg=MUTED,
                 font=("Segoe UI", 10)).pack(side="right")
        self._action_btn(top, "↻ Refresh", self._load_orders).pack(side="right", padx=8)
        status_combo.bind("<<ComboboxSelected>>", lambda _: self._load_orders())

        cols   = ("Order ID", "Customer", "Restaurant", "Total", "Status", "Payment", "Date")
        widths = [120, 130, 160, 90, 130, 80, 100]
        self.orders_tree = self._build_tree(frame, cols, widths, height=16,
                                             anchors={"Total": "e"})

        act_f = tk.Frame(frame, bg=BG)
        act_f.pack(fill="x", padx=10, pady=6)
        tk.Label(act_f, text="Update selected order to:",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(side="left")
        self.new_status_var = tk.StringVar(value="accepted")
        ttk.Combobox(act_f, textvariable=self.new_status_var,
                     values=["accepted", "preparing", "out for delivery",
                             "delivered", "cancelled"],
                     state="readonly", width=20).pack(side="left", padx=8)
        self._action_btn(act_f, "Update Status",
                         self._update_order_status).pack(side="left")
        self._load_orders()

    def _load_orders(self):
        status = self.ord_status_var.get()
        self.all_orders = models.get_all_orders(
            None if status == "All" else status)
        self.orders_tree.delete(*self.orders_tree.get_children())
        for o in self.all_orders:
            self.orders_tree.insert("", "end", values=(
                o["order_id"],
                o.get("customer_name", ""),
                o.get("restaurant_name") or o.get("restaurant", ""),
                f"Rs. {o['total']:.2f}",
                o["status"].title(),
                o.get("payment_method", "cash"),
                str(o["order_date"])[:10],
            ))

    def _update_order_status(self):
        sel = self.orders_tree.selection()
        if not sel:
            messagebox.showwarning("Select Order", "Select an order first.", parent=self)
            return
        idx   = self.orders_tree.index(sel[0])
        order = self.all_orders[idx]
        models.update_order_status(order["order_id"], self.new_status_var.get())
        messagebox.showinfo("Updated", "Order status updated!", parent=self)
        self._load_orders()

    # ══════════════════════════════════════════════════════════════════════
    # TAB 3 — RESTAURANTS
    # ══════════════════════════════════════════════════════════════════════
    def _tab_restaurants(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  🏠 Restaurants  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Restaurants",
                 font=("Georgia", 14, "bold"), fg=GOLD, bg=BG).pack(side="left")
        self._action_btn(top, "↻ Refresh", self._load_restaurants).pack(side="right")

        cols   = ("ID", "Name", "Cuisine", "Location", "Status", "Rating")
        widths = [50, 180, 120, 180, 90, 70]
        self.rest_tree = self._build_tree(frame, cols, widths, height=16,
                                           anchors={"Rating": "center"})

        act_f = tk.Frame(frame, bg=BG)
        act_f.pack(fill="x", padx=10, pady=6)
        tk.Label(act_f, text="Set status:",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(side="left")
        self.rest_status_var = tk.StringVar(value="active")
        ttk.Combobox(act_f, textvariable=self.rest_status_var,
                     values=["active", "inactive", "pending"],
                     state="readonly", width=14).pack(side="left", padx=8)
        self._action_btn(act_f, "Apply", self._update_rest_status).pack(side="left")
        self._load_restaurants()

    def _load_restaurants(self):
        self.restaurants = models.get_restaurants("all")
        self.rest_tree.delete(*self.rest_tree.get_children())
        for r in self.restaurants:
            self.rest_tree.insert("", "end", values=(
                r["restaurant_id"], r["name"], r["cuisine"],
                r["location"], r["status"], r["rating"],
            ))

    def _update_rest_status(self):
        sel = self.rest_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Select a restaurant.", parent=self)
            return
        idx = self.rest_tree.index(sel[0])
        models.update_restaurant_status(
            self.restaurants[idx]["restaurant_id"],
            self.rest_status_var.get())
        self._load_restaurants()

    # ══════════════════════════════════════════════════════════════════════
    # TAB 4 — USERS
    # ══════════════════════════════════════════════════════════════════════
    def _tab_users(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  👥 Users  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="All Users",
                 font=("Georgia", 14, "bold"), fg=GOLD, bg=BG).pack(side="left")
        self._action_btn(top, "↻ Refresh", self._load_users).pack(side="right")

        cols   = ("ID", "Name", "Email", "Phone", "Role", "Joined")
        widths = [50, 150, 200, 120, 90, 110]
        self.users_tree = self._build_tree(frame, cols, widths, height=18)

        self._action_btn(frame, "🗑  Delete Selected User",
                         self._delete_user, color=DANGER).pack(
            anchor="w", padx=10, pady=6)
        self._load_users()

    def _load_users(self):
        self.all_users = auth.get_all_users()
        self.users_tree.delete(*self.users_tree.get_children())
        for u in self.all_users:
            self.users_tree.insert("", "end", values=(
                u["user_id"], u["name"], u["email"],
                u["phone"], u["role"].title(),
                str(u["created_at"])[:10],
            ))

    def _delete_user(self):
        sel = self.users_tree.selection()
        if not sel:
            return
        idx  = self.users_tree.index(sel[0])
        user = self.all_users[idx]
        if user["email"] == self.user["email"]:
            messagebox.showerror("Error", "Cannot delete yourself.", parent=self)
            return
        if messagebox.askyesno("Confirm", f"Delete {user['name']}?", parent=self):
            auth.delete_user(user["email"])
            self._load_users()

    # ══════════════════════════════════════════════════════════════════════
    # TAB 5 — RIDERS
    # ══════════════════════════════════════════════════════════════════════
    def _tab_riders(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  🛵 Riders  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Delivery Riders",
                 font=("Georgia", 14, "bold"), fg=GOLD, bg=BG).pack(side="left")
        self._action_btn(top, "↻ Refresh", self._load_riders).pack(side="right")

        cols   = ("ID", "Name", "Phone", "Vehicle", "Zone", "Rating", "Available")
        widths = [50, 150, 120, 100, 100, 70, 80]
        self.riders_tree = self._build_tree(frame, cols, widths, height=12,
                                             anchors={"Rating": "center",
                                                      "Available": "center"})

        act = tk.Frame(frame, bg=BG)
        act.pack(fill="x", padx=10, pady=4)
        self._action_btn(act, "⇄ Toggle Availability",
                         self._toggle_rider).pack(side="left")
        self._action_btn(act, "🗑  Delete Rider",
                         self._delete_rider, color=DANGER).pack(side="left", padx=8)

        add_f = tk.Frame(frame, bg=CARD,
                         highlightbackground=BORDER, highlightthickness=1)
        add_f.pack(fill="x", padx=10, pady=8)
        tk.Label(add_f, text="Add New Rider",
                 font=("Georgia", 11, "bold"), fg=GOLD2, bg=CARD
                 ).pack(anchor="w", padx=12, pady=(10, 4))

        row1 = tk.Frame(add_f, bg=CARD)
        row1.pack(fill="x", padx=12, pady=(0, 10))

        self._rider_fields: dict[str, tk.Entry] = {}
        for lbl in ["Name", "Phone", "Vehicle", "Zone"]:
            tk.Label(row1, text=lbl + ":", bg=CARD, fg=MUTED,
                     font=("Segoe UI", 9)).pack(side="left")
            e = tk.Entry(row1, width=14, font=("Segoe UI", 9),
                         bg=INPUT, fg=TEXT, insertbackground=GOLD,
                         relief="flat", bd=0)
            e.pack(side="left", padx=(2, 12), ipady=4)
            self._rider_fields[lbl] = e

        self._action_btn(add_f, "➕ Add Rider",
                         self._add_rider).pack(anchor="e", padx=12, pady=(0, 10))
        self._load_riders()

    def _add_rider(self):
        f = self._rider_fields
        models.add_rider(
            f["Name"].get(), f["Phone"].get(),
            f["Vehicle"].get() or "Bike",
            f["Zone"].get() or "General",
        )
        for e in f.values():
            e.delete(0, tk.END)
        self._load_riders()

    def _load_riders(self):
        self.riders = models.get_riders()
        self.riders_tree.delete(*self.riders_tree.get_children())
        for r in self.riders:
            self.riders_tree.insert("", "end", values=(
                r["rider_id"], r["name"], r["phone"],
                r["vehicle"], r["zone"], r["rating"],
                "Yes" if r["is_available"] else "No",
            ))

    def _toggle_rider(self):
        sel = self.riders_tree.selection()
        if not sel:
            return
        idx = self.riders_tree.index(sel[0])
        models.toggle_rider(self.riders[idx]["rider_id"])
        self._load_riders()

    def _delete_rider(self):
        sel = self.riders_tree.selection()
        if not sel:
            return
        idx = self.riders_tree.index(sel[0])
        r   = self.riders[idx]
        if messagebox.askyesno("Confirm", f"Delete rider {r['name']}?", parent=self):
            models.delete_rider(r["rider_id"])
            self._load_riders()

    # ══════════════════════════════════════════════════════════════════════
    # TAB 6 — REVIEWS  (NEW)
    # ══════════════════════════════════════════════════════════════════════
    def _tab_reviews(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  ⭐ Reviews  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Customer Reviews",
                 font=("Georgia", 14, "bold"), fg=GOLD, bg=BG).pack(side="left")
        self._action_btn(top, "↻ Refresh", self._load_reviews).pack(side="right")

        # Filter by restaurant
        filter_f = tk.Frame(frame, bg=BG)
        filter_f.pack(fill="x", padx=10, pady=(0, 4))
        tk.Label(filter_f, text="Filter by restaurant:",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(side="left")
        self.review_rest_var = tk.StringVar(value="All")
        self.review_rest_combo = ttk.Combobox(
            filter_f, textvariable=self.review_rest_var,
            values=["All"], state="readonly", width=30)
        self.review_rest_combo.pack(side="left", padx=8)
        self.review_rest_combo.bind("<<ComboboxSelected>>",
                                    lambda _: self._load_reviews())

        cols   = ("ID", "Customer", "Restaurant", "Rating", "Comment", "Date")
        widths = [60, 140, 160, 70, 320, 100]
        self.reviews_tree = self._build_tree(
            frame, cols, widths, height=18,
            anchors={"Rating": "center"})

        self._action_btn(frame, "🗑  Delete Selected Review",
                         self._delete_review, color=DANGER).pack(
            anchor="w", padx=10, pady=6)

        self._load_reviews()

    def _load_reviews(self):
        self.all_reviews = models.get_all_reviews()
        # Populate restaurant filter
        names = sorted({r.get("restaurant_name", "") for r in self.all_reviews
                        if r.get("restaurant_name")})
        self.review_rest_combo.configure(values=["All"] + names)

        sel_rest = self.review_rest_var.get()
        filtered = self.all_reviews if sel_rest == "All" else [
            r for r in self.all_reviews
            if r.get("restaurant_name") == sel_rest
        ]

        self.reviews_tree.delete(*self.reviews_tree.get_children())
        for r in filtered:
            comment = r.get("comment", "") or ""
            self.reviews_tree.insert("", "end", values=(
                r["review_id"],
                r.get("customer_name", ""),
                r.get("restaurant_name", ""),
                f"{'★' * int(r['rating'])}  {r['rating']}",
                comment[:80] + ("…" if len(comment) > 80 else ""),
                str(r.get("created_at", ""))[:10],
            ))

    def _delete_review(self):
        sel = self.reviews_tree.selection()
        if not sel:
            return
        idx = self.reviews_tree.index(sel[0])
        rev = self.all_reviews[idx]
        if messagebox.askyesno("Confirm",
                               f"Delete review #{rev['review_id']}?", parent=self):
            models.delete_review(rev["review_id"])
            self._load_reviews()

    # ══════════════════════════════════════════════════════════════════════
    # TAB 7 — REPORTS  (NEW)
    # ══════════════════════════════════════════════════════════════════════
    def _tab_reports(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  📈 Reports  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="System-Wide Reports",
                 font=("Georgia", 14, "bold"), fg=GOLD, bg=BG).pack(side="left")
        self._action_btn(top, "↻ Refresh All", self._load_reports).pack(side="right")

        # ── KPI summary row ───────────────────────────────────────────────
        kpi_row = tk.Frame(frame, bg=BG)
        kpi_row.pack(fill="x", padx=10, pady=(4, 8))

        self._report_kpis: dict[str, tk.Label] = {}
        kpi_defs = [
            ("total_orders",    "Total Orders",     GOLD,       "📦"),
            ("total_revenue",   "Total Revenue",    SUCCESS_FG, "💰"),
            ("total_users",     "Total Customers",  INFO_FG,    "👥"),
            ("total_restaurants","Restaurants",     WARN_FG,    "🏠"),
            ("avg_rating",      "Avg Rating",       GOLD,       "⭐"),
        ]
        bg_cycle = [CARD, SUCCESS, INFO, WARN, CARD]
        for (key, label, fg, icon), bg_col in zip(kpi_defs, bg_cycle):
            c = tk.Frame(kpi_row, bg=bg_col, width=185, height=90,
                         highlightbackground=BORDER, highlightthickness=1)
            c.pack(side="left", padx=5, pady=2)
            c.pack_propagate(False)
            tk.Label(c, text=f"{icon}  {label}",
                     font=("Segoe UI", 9), fg=MUTED, bg=bg_col).pack(pady=(10, 2))
            v = tk.Label(c, text="—", font=("Georgia", 18, "bold"), fg=fg, bg=bg_col)
            v.pack()
            self._report_kpis[key] = v

        # ── Top restaurants by revenue ────────────────────────────────────
        tk.Label(frame, text="Top Restaurants by Revenue",
                 font=("Georgia", 12, "bold"), fg=GOLD2, bg=BG
                 ).pack(anchor="w", padx=12, pady=(6, 2))

        cols_r  = ("Rank", "Restaurant", "Cuisine", "Orders", "Revenue", "Avg Rating")
        widths_r = [50, 200, 130, 80, 120, 90]
        self.top_rest_tree = self._build_tree(
            frame, cols_r, widths_r, height=6,
            anchors={"Rank": "center", "Orders": "center",
                     "Revenue": "e", "Avg Rating": "center"})

        # ── Payment method breakdown ──────────────────────────────────────
        tk.Label(frame, text="Payment Method Breakdown",
                 font=("Georgia", 12, "bold"), fg=GOLD2, bg=BG
                 ).pack(anchor="w", padx=12, pady=(8, 2))

        cols_p  = ("Payment Method", "Orders", "Total Revenue", "% of Orders")
        widths_p = [160, 100, 150, 120]
        self.pay_tree = self._build_tree(
            frame, cols_p, widths_p, height=5,
            anchors={"Orders": "center", "Total Revenue": "e",
                     "% of Orders": "center"})

        self._load_reports()

    def _load_reports(self):
        # ── KPIs ─────────────────────────────────────────────────────────
        summary = models.get_summary()
        self._report_kpis["total_orders"].config(
            text=str(summary.get("total_orders", 0)))
        rev = summary.get("total_revenue", 0)
        self._report_kpis["total_revenue"].config(
            text=f"Rs. {rev:,.0f}")
        self._report_kpis["total_users"].config(
            text=str(summary.get("total_users", 0)))
        # count active restaurants
        rests = models.get_restaurants("all")
        self._report_kpis["total_restaurants"].config(text=str(len(rests)))
        avg = models.get_average_rating()
        self._report_kpis["avg_rating"].config(
            text=f"{avg:.1f} ★" if avg else "—")

        # ── Top restaurants ───────────────────────────────────────────────
        self.top_rest_tree.delete(*self.top_rest_tree.get_children())
        top_rests = models.get_top_restaurants()
        for rank, r in enumerate(top_rests, 1):
            self.top_rest_tree.insert("", "end", values=(
                rank,
                r.get("name", ""),
                r.get("cuisine", ""),
                r.get("total_orders", 0),
                f"Rs. {r.get('total_revenue', 0):,.0f}",
                f"{r.get('avg_rating', 0):.1f}",
            ))

        # ── Payment breakdown ─────────────────────────────────────────────
        self.pay_tree.delete(*self.pay_tree.get_children())
        pay_data   = models.get_payment_breakdown()
        total_ords = sum(p.get("order_count", 0) for p in pay_data) or 1
        for p in pay_data:
            cnt = p.get("order_count", 0)
            self.pay_tree.insert("", "end", values=(
                p.get("payment_method", "cash").title(),
                cnt,
                f"Rs. {p.get('total_revenue', 0):,.0f}",
                f"{cnt / total_ords * 100:.1f}%",
            ))

    # ══════════════════════════════════════════════════════════════════════
    # TAB 8 — CHANGE PASSWORD
    # ══════════════════════════════════════════════════════════════════════
    def _tab_change_password(self):
        outer = tk.Frame(self.nb, bg=BG)
        self.nb.add(outer, text="  🔒 Change Password  ")

        holder = tk.Frame(outer, bg=BG)
        holder.pack(expand=True)

        card = tk.Frame(holder, bg=CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(padx=20, pady=20)

        pad = tk.Frame(card, bg=CARD)
        pad.pack(padx=40, pady=32)

        tk.Label(pad, text="🔒  Change Password",
                 font=("Georgia", 16, "bold"), fg=GOLD, bg=CARD).pack(anchor="w")
        tk.Label(pad, text="Enter your current password, then choose a new one.",
                 font=("Segoe UI", 9), fg=MUTED, bg=CARD
                 ).pack(anchor="w", pady=(4, 14))
        tk.Frame(pad, bg=BORDER, height=1).pack(fill="x", pady=(0, 18))

        pw_vars: dict[str, tk.StringVar] = {}

        def _pw_field(label_text: str, key: str):
            row = tk.Frame(pad, bg=CARD)
            row.pack(fill="x", pady=7)
            tk.Label(row, text=label_text, font=("Segoe UI", 9, "bold"),
                     fg=GOLD2, bg=CARD, width=20, anchor="w").pack(side="left")
            var = tk.StringVar()
            pw_vars[key] = var
            ef = tk.Frame(row, bg=INPUT, highlightthickness=1,
                          highlightbackground=BORDER, highlightcolor=GOLD2)
            ef.pack(side="left")
            ent = tk.Entry(ef, textvariable=var, show="●",
                           bg=INPUT, fg=TEXT, insertbackground=GOLD,
                           selectbackground=GOLD3, selectforeground=TEXT,
                           relief="flat", font=("Segoe UI", 10), width=28, bd=6)
            ent.pack(side="left")
            eye_var = tk.BooleanVar(value=False)
            btn_ref = [None]

            def _toggle(e=ent, v=eye_var, ref=btn_ref):
                v.set(not v.get())
                e.configure(show="" if v.get() else "●")
                ref[0].configure(text="🙈" if v.get() else "👁")

            eye_btn = tk.Button(ef, text="👁", command=_toggle,
                                bg=INPUT, fg=MUTED, relief="flat", cursor="hand2",
                                font=("Segoe UI", 10),
                                activebackground=INPUT, activeforeground=GOLD2,
                                bd=0, padx=4)
            eye_btn.pack(side="left", padx=(0, 2))
            btn_ref[0] = eye_btn

        _pw_field("Current Password", "current")
        _pw_field("New Password",     "new")
        _pw_field("Confirm Password", "confirm")

        tk.Frame(pad, bg=BORDER, height=1).pack(fill="x", pady=(20, 0))

        status_lbl = tk.Label(pad, text="", font=("Segoe UI", 9),
                              bg=CARD, fg=SUCCESS_FG)
        status_lbl.pack(anchor="w", pady=(8, 0))

        def _do_change():
            cur     = pw_vars["current"].get()
            new     = pw_vars["new"].get()
            confirm = pw_vars["confirm"].get()
            if not cur or not new or not confirm:
                status_lbl.config(text="⚠  All fields are required.", fg=WARN_FG)
                return
            if new != confirm:
                status_lbl.config(text="⚠  New passwords do not match.", fg=WARN_FG)
                return
            if len(new) < 6:
                status_lbl.config(
                    text="⚠  Password must be at least 6 characters.", fg=WARN_FG)
                return
            if not auth.verify_password(self.user['email'], cur):
                status_lbl.config(text="✖  Current password is incorrect.", fg=DANGER_FG)
                return
            auth.change_password(self.user['email'], new)
            for v in pw_vars.values():
                v.set("")
            status_lbl.config(text="✔  Password changed successfully!", fg=SUCCESS_FG)

        tk.Button(pad, text="  Update Password  ", command=_do_change,
                  bg=GOLD3, fg=TEXT, font=("Segoe UI", 10, "bold"),
                  relief="flat", cursor="hand2",
                  activebackground=GOLD2, activeforeground=BG,
                  padx=20, pady=10).pack(anchor="e", pady=(14, 0))