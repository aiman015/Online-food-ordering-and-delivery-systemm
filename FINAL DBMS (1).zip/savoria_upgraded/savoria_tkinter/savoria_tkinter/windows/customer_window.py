# windows/customer_window.py — Savoria Customer Dashboard
# Fixes applied:
#   1. _change_password now calls auth.change_password() — no more hash/plain mismatch
#   2. Current password field added before allowing password change
#   3. status_step mapped from status string — tracker now works correctly
#   4. has_review() check used to prevent duplicate reviews
#   5. Dead hashlib import and _hash_password removed
#   6. Profile tab eye toggle kept and working

import tkinter as tk
from tkinter import ttk, messagebox
import models
import auth

# ── Palette ────────────────────────────────────────────────────────────────
BG      = "#0D0A14"
CARD    = "#160F2A"
INPUT   = "#1E1535"
HEADER  = "#2A1650"
GOLD    = "#E8C46A"
GOLD2   = "#C9A84C"
GOLD3   = "#8A6A1F"
TEXT    = "#EDE8D6"
MUTED   = "#7A6E8A"
BORDER  = "#2E1F54"
SUCCESS = "#3A7D44"
DANGER  = "#7D3A3A"
HOVER   = "#1F1640"
WARN_FG = "#E8A84C"
DANGER_FG = "#ef4444"
SUCCESS_FG = "#22c55e"

CUISINE_ICONS = {
    "pakistani": "🍛", "chinese": "🥢", "italian": "🍕",
    "american": "🍔", "fast food": "🌮", "bbq": "🔥",
    "bakery": "🧁", "desserts": "🍨", "drinks": "🧃",
    "seafood": "🦞", "breakfast": "🍳", "sushi": "🍣",
    "default": "🍽",
}

STATUS_STEPS = [
    ("Pending",          "🕐"),
    ("Accepted",         "✅"),
    ("Preparing",        "👨‍🍳"),
    ("Out for Delivery", "🛵"),
    ("Delivered",        "🎉"),
]

# Maps status string → 1-based step index for the tracker
STATUS_MAP = {
    "pending":          1,
    "accepted":         2,
    "preparing":        3,
    "ready for pickup": 3,
    "out for delivery": 4,
    "delivered":        5,
}


def cuisine_icon(cuisine: str) -> str:
    return CUISINE_ICONS.get(str(cuisine).lower().strip(), CUISINE_ICONS["default"])


# ── Main window ─────────────────────────────────────────────────────────────
class CustomerWindow(tk.Toplevel):
    def __init__(self, master, user: dict):
        super().__init__(master)
        self.user = user
        self.cart: list[dict] = []
        self.cart_restaurant_id: int | None = None
        self.restaurants: list[dict] = []
        self._selected_order: dict | None = None

        self.title(f"Savoria — {user['name']}")
        self.geometry("1200x740")
        self.configure(bg=BG)
        self._build_ui()
        self._center(1200, 740)

    # ── helpers ────────────────────────────────────────────────────────────
    def _center(self, w: int, h: int):
        self.update_idletasks()
        x = max(0, (self.winfo_screenwidth()  - w) // 2)
        y = max(0, (self.winfo_screenheight() - h) // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _center_toplevel(self, win: tk.Toplevel, w: int, h: int):
        win.update_idletasks()
        x = max(0, (win.winfo_screenwidth()  - w) // 2)
        y = max(0, (win.winfo_screenheight() - h) // 2)
        win.geometry(f"{w}x{h}+{x}+{y}")

    # ── logout ─────────────────────────────────────────────────────────────
    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?",
                                parent=self):
            self.destroy()
            self.master.destroy()

    # ── UI skeleton ────────────────────────────────────────────────────────
    def _build_ui(self):
        nav = tk.Frame(self, bg=HEADER, height=58)
        nav.pack(fill="x")
        nav.pack_propagate(False)
        tk.Label(nav, text="🍽  Savoria",
                 font=("Georgia", 19, "bold"),
                 fg=GOLD, bg=HEADER).pack(side="left", padx=20)
        tk.Button(nav, text="⇢ Logout", command=self._logout,
                  bg=DANGER, fg=TEXT,
                  font=("Segoe UI", 10, "bold"),
                  relief="flat", cursor="hand2",
                  padx=12, pady=4).pack(side="right", padx=16, pady=10)
        tk.Label(nav, text=f"👤 {self.user['name']}",
                 font=("Segoe UI", 11), fg=GOLD2, bg=HEADER).pack(side="right", padx=4)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=CARD, borderwidth=0)
        style.configure("TNotebook.Tab",
                         font=("Segoe UI", 11), padding=[14, 6],
                         background=CARD, foreground=MUTED)
        style.map("TNotebook.Tab",
                  background=[("selected", BG)],
                  foreground=[("selected", GOLD)])
        style.configure("Treeview",
                         background=CARD, foreground=TEXT,
                         fieldbackground=CARD, rowheight=26, borderwidth=0)
        style.configure("Treeview.Heading",
                         background=HEADER, foreground=GOLD2, relief="flat")
        style.map("Treeview",
                  background=[("selected", GOLD3)],
                  foreground=[("selected", TEXT)])

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True)

        self._tab_restaurants()
        self._tab_orders()
        self._tab_profile()

    # ══════════════════════════════════════════════════════════════════════
    # TAB 1 — RESTAURANTS
    # ══════════════════════════════════════════════════════════════════════
    def _tab_restaurants(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  🏠 Restaurants  ")

        top = tk.Frame(frame, bg=BG, pady=10)
        top.pack(fill="x", padx=16)
        tk.Label(top, text="Browse Restaurants",
                 font=("Georgia", 15, "bold"),
                 fg=GOLD, bg=BG).pack(side="left")

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._filter_cards())
        search_entry = tk.Entry(top, textvariable=self.search_var,
                                font=("Segoe UI", 11), relief="flat",
                                bg=INPUT, fg=TEXT, bd=0,
                                insertbackground=GOLD)
        search_entry.pack(side="right", ipadx=8, ipady=5)
        tk.Frame(top, bg=GOLD3, height=2).pack(side="right", fill="y")
        tk.Label(top, text="🔍 ", font=("Segoe UI", 12), bg=BG, fg=GOLD2).pack(side="right")

        canvas_frame = tk.Frame(frame, bg=BG)
        canvas_frame.pack(fill="both", expand=True, padx=12, pady=4)

        self.rest_canvas = tk.Canvas(canvas_frame, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(canvas_frame, orient="vertical",
                                   command=self.rest_canvas.yview)
        self.rest_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.rest_canvas.pack(side="left", fill="both", expand=True)

        self.cards_frame = tk.Frame(self.rest_canvas, bg=BG)
        self.cards_window = self.rest_canvas.create_window(
            (0, 0), window=self.cards_frame, anchor="nw")
        self.cards_frame.bind("<Configure>",
            lambda e: self.rest_canvas.configure(
                scrollregion=self.rest_canvas.bbox("all")))
        self.rest_canvas.bind("<Configure>",
            lambda e: self.rest_canvas.itemconfig(
                self.cards_window, width=e.width))

        self.rest_canvas.bind("<Enter>",
            lambda _: self.rest_canvas.bind_all(
                "<MouseWheel>", self._on_mousewheel))
        self.rest_canvas.bind("<Leave>",
            lambda _: self.rest_canvas.unbind_all("<MouseWheel>"))

        self._load_restaurant_cards()

    def _on_mousewheel(self, event):
        self.rest_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _load_restaurant_cards(self):
        self.restaurants = models.get_restaurants("active")
        self._render_cards(self.restaurants)

    def _filter_cards(self):
        q = self.search_var.get().lower()
        filtered = [
            r for r in self.restaurants
            if q in r["name"].lower()
            or q in str(r.get("cuisine", "")).lower()
            or q in str(r.get("location", "")).lower()
        ]
        self._render_cards(filtered)

    def _render_cards(self, restaurants: list[dict]):
        for w in self.cards_frame.winfo_children():
            w.destroy()

        if not restaurants:
            tk.Label(self.cards_frame, text="No restaurants found.",
                     font=("Segoe UI", 13), fg=MUTED, bg=BG).pack(pady=40)
            return

        COLS = 3
        for i, rest in enumerate(restaurants):
            row, col = divmod(i, COLS)
            card = self._make_restaurant_card(self.cards_frame, rest)
            card.grid(row=row, column=col, padx=12, pady=12, sticky="nsew")

        for c in range(COLS):
            self.cards_frame.columnconfigure(c, weight=1)

    def _make_restaurant_card(self, parent: tk.Frame, rest: dict) -> tk.Frame:
        card = tk.Frame(parent, bg=CARD, relief="flat",
                        highlightbackground=BORDER, highlightthickness=1)

        icon   = cuisine_icon(rest.get("cuisine", ""))
        rating = rest.get("rating", 0.0)
        stars  = "★" * int(rating) + "☆" * (5 - int(rating))

        banner = tk.Frame(card, bg=HEADER, height=70)
        banner.pack(fill="x")
        banner.pack_propagate(False)
        tk.Label(banner, text=icon, font=("Segoe UI Emoji", 28),
                 bg=HEADER).pack(expand=True)

        body = tk.Frame(card, bg=CARD, padx=14, pady=10)
        body.pack(fill="x")

        tk.Label(body, text=rest["name"],
                 font=("Georgia", 12, "bold"),
                 fg=GOLD, bg=CARD, anchor="w").pack(fill="x")

        meta = tk.Frame(body, bg=CARD)
        meta.pack(fill="x", pady=2)
        tk.Label(meta, text=rest.get("cuisine", ""),
                 font=("Segoe UI", 9), fg=MUTED, bg=CARD).pack(side="left")
        tk.Label(meta, text=f"{stars} {rating:.1f}",
                 font=("Segoe UI", 9), fg=GOLD2, bg=CARD).pack(side="right")

        if rest.get("location"):
            tk.Label(body, text=f"📍 {rest['location']}",
                     font=("Segoe UI", 9), fg=MUTED, bg=CARD,
                     anchor="w").pack(fill="x")

        btn = tk.Button(card, text="View Menu →",
                        font=("Segoe UI", 10, "bold"),
                        bg=GOLD3, fg=TEXT, relief="flat",
                        cursor="hand2", pady=8,
                        command=lambda r=rest: self._open_menu_popup(r))
        btn.pack(fill="x")

        def on_enter(e, c=card, b=btn):
            c.configure(highlightbackground=GOLD, highlightthickness=2)
            b.configure(bg=GOLD2, fg=BG)

        def on_leave(e, c=card, b=btn):
            c.configure(highlightbackground=BORDER, highlightthickness=1)
            b.configure(bg=GOLD3, fg=TEXT)

        for w in [card, banner, body, meta, btn]:
            w.bind("<Enter>", on_enter)
            w.bind("<Leave>", on_leave)

        return card

    # ══════════════════════════════════════════════════════════════════════
    # MENU POPUP
    # ══════════════════════════════════════════════════════════════════════
    def _open_menu_popup(self, restaurant: dict):
        popup = tk.Toplevel(self)
        popup.title(f"{restaurant['name']} — Menu")
        popup.configure(bg=BG)
        popup.grab_set()
        popup.focus_set()
        self._center_toplevel(popup, 820, 600)

        hdr = tk.Frame(popup, bg=HEADER, height=60)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        icon = cuisine_icon(restaurant.get("cuisine", ""))
        tk.Label(hdr, text=f"{icon}  {restaurant['name']}",
                 font=("Georgia", 15, "bold"),
                 fg=GOLD, bg=HEADER).pack(side="left", padx=20)
        tk.Button(hdr, text="✕ Close", command=popup.destroy,
                  bg=GOLD3, fg=TEXT, font=("Segoe UI", 9),
                  relief="flat", cursor="hand2", padx=10
                  ).pack(side="right", padx=12, pady=10)

        content = tk.Frame(popup, bg=BG)
        content.pack(fill="both", expand=True, padx=14, pady=10)

        top_row = tk.Frame(content, bg=BG)
        top_row.pack(fill="x", pady=(0, 8))
        tk.Label(top_row, text="Category:",
                 font=("Segoe UI", 10), fg=MUTED, bg=BG).pack(side="left")
        cat_var = tk.StringVar(value="All")
        cats    = ["All"] + models.get_menu_categories(restaurant["restaurant_id"])
        cat_combo = ttk.Combobox(top_row, textvariable=cat_var,
                                  values=cats, width=16, state="readonly")
        cat_combo.pack(side="left", padx=8)

        cols = ("Name", "Description", "Category", "Price")
        tree = ttk.Treeview(content, columns=cols, show="headings", height=16)
        tree.heading("Name",        text="Name")
        tree.heading("Description", text="Description")
        tree.heading("Category",    text="Category")
        tree.heading("Price",       text="Price")
        tree.column("Name",        width=200)
        tree.column("Description", width=280)
        tree.column("Category",    width=110)
        tree.column("Price",       width=90, anchor="e")

        vsb = ttk.Scrollbar(content, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)

        menu_items_ref: list[dict] = []

        def load_menu(cat: str | None = None):
            menu_items_ref.clear()
            items = models.get_menu_items(
                restaurant["restaurant_id"],
                None if (not cat or cat == "All") else cat,
            )
            menu_items_ref.extend(items)
            tree.delete(*tree.get_children())
            for it in items:
                desc = it.get("description", "")
                tree.insert("", "end", values=(
                    it["name"],
                    desc[:45] + ("…" if len(desc) > 45 else ""),
                    it["category"],
                    f"Rs. {it['price']:.2f}",
                ))

        cat_combo.bind("<<ComboboxSelected>>", lambda _: load_menu(cat_var.get()))
        load_menu()

        bottom = tk.Frame(popup, bg=CARD, pady=10)
        bottom.pack(fill="x", padx=14)

        qty_var = tk.IntVar(value=1)
        tk.Label(bottom, text="Qty:", font=("Segoe UI", 10),
                 bg=CARD, fg=TEXT).pack(side="left")
        tk.Spinbox(bottom, from_=1, to=20, textvariable=qty_var,
                   width=4, font=("Segoe UI", 10),
                   bg=INPUT, fg=TEXT, buttonbackground=GOLD3
                   ).pack(side="left", padx=6)

        def add_to_cart():
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Select Item",
                                       "Please select a menu item.", parent=popup)
                return
            idx  = tree.index(sel[0])
            item = menu_items_ref[idx]
            qty  = qty_var.get()

            if self.cart and self.cart_restaurant_id != restaurant["restaurant_id"]:
                if not messagebox.askyesno(
                    "New Restaurant",
                    "Your cart has items from another restaurant.\n"
                    "Clear cart and start fresh?",
                    parent=popup,
                ):
                    return
                self.cart.clear()

            self.cart_restaurant_id = restaurant["restaurant_id"]
            for c in self.cart:
                if c["item_id"] == item["item_id"]:
                    c["qty"] += qty
                    messagebox.showinfo("Cart",
                                        f"Updated: {item['name']} → ×{c['qty']}",
                                        parent=popup)
                    return

            self.cart.append({
                "item_id":       item["item_id"],
                "name":          item["name"],
                "price":         float(item["price"]),
                "qty":           qty,
                "restaurant_id": restaurant["restaurant_id"],
            })
            messagebox.showinfo("Added!",
                                f"✓ {item['name']} ×{qty} added to cart.",
                                parent=popup)

        tk.Button(bottom, text="➕ Add to Cart",
                  command=add_to_cart,
                  bg=GOLD3, fg=TEXT,
                  font=("Segoe UI", 11, "bold"),
                  relief="flat", cursor="hand2",
                  padx=20, pady=6).pack(side="left", padx=10)

        tk.Button(bottom, text="🛒 Go to Checkout",
                  command=lambda: (popup.destroy(),
                                   self._open_cart_window(restaurant)),
                  bg=SUCCESS, fg=TEXT,
                  font=("Segoe UI", 11, "bold"),
                  relief="flat", cursor="hand2",
                  padx=20, pady=6).pack(side="right", padx=10)

    # ══════════════════════════════════════════════════════════════════════
    # CART / CHECKOUT WINDOW
    # ══════════════════════════════════════════════════════════════════════
    def _open_cart_window(self, restaurant: dict | None = None):
        if not self.cart:
            messagebox.showinfo("Cart Empty",
                                "Your cart is empty. Add some items first!")
            return

        cwin = tk.Toplevel(self)
        cwin.title("Your Cart")
        cwin.configure(bg=BG)
        cwin.grab_set()
        self._center_toplevel(cwin, 520, 660)

        hdr = tk.Frame(cwin, bg=HEADER, height=52)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="🛒  Your Cart",
                 font=("Georgia", 14, "bold"),
                 fg=GOLD, bg=HEADER).pack(side="left", padx=20)

        body = tk.Frame(cwin, bg=BG, padx=20, pady=10)
        body.pack(fill="both", expand=True)

        cart_lb = tk.Listbox(body, font=("Segoe UI", 10), height=10,
                             bd=0, highlightthickness=1,
                             highlightbackground=BORDER,
                             bg=CARD, fg=TEXT,
                             selectbackground=GOLD3,
                             selectforeground=TEXT)
        cart_lb.pack(fill="both", expand=True)

        total_lbl = tk.Label(body, text="",
                             font=("Segoe UI", 12, "bold"),
                             fg=GOLD, bg=BG)
        total_lbl.pack(anchor="e", pady=6)

        def refresh():
            cart_lb.delete(0, tk.END)
            total = sum(c["price"] * c["qty"] for c in self.cart)
            for c in self.cart:
                cart_lb.insert(
                    tk.END,
                    f"  {c['name']}  ×{c['qty']}  → Rs. {c['price']*c['qty']:.0f}"
                )
            total_lbl.config(text=f"Total: Rs. {total:.2f}  + Rs. 50 delivery")

        refresh()

        def remove_item():
            sel = cart_lb.curselection()
            if sel:
                del self.cart[sel[0]]
                refresh()

        def clear_cart():
            self.cart.clear()
            self.cart_restaurant_id = None
            refresh()

        btn_row = tk.Frame(body, bg=BG)
        btn_row.pack(fill="x", pady=4)
        tk.Button(btn_row, text="Remove Selected", command=remove_item,
                  bg=DANGER, fg=TEXT, font=("Segoe UI", 9),
                  relief="flat", cursor="hand2").pack(side="left")
        tk.Button(btn_row, text="Clear All", command=clear_cart,
                  bg=MUTED, fg=TEXT, font=("Segoe UI", 9),
                  relief="flat", cursor="hand2").pack(side="left", padx=8)

        opt_frame = tk.Frame(body, bg=BG)
        opt_frame.pack(fill="x", pady=8)

        delivery_var = tk.StringVar(value="Delivery")
        tk.Label(opt_frame, text="Type:", font=("Segoe UI", 10),
                 fg=TEXT, bg=BG).grid(row=0, column=0, sticky="w")
        for i, v in enumerate(["Delivery", "Pickup"]):
            tk.Radiobutton(opt_frame, text=v, variable=delivery_var,
                           value=v, bg=BG, fg=TEXT,
                           selectcolor=CARD,
                           activebackground=BG, activeforeground=GOLD,
                           font=("Segoe UI", 10)
                           ).grid(row=0, column=i + 1, padx=4, sticky="w")

        pay_var = tk.StringVar(value="cash")
        tk.Label(opt_frame, text="Payment:", font=("Segoe UI", 10),
                 fg=TEXT, bg=BG).grid(row=1, column=0, sticky="w", pady=4)
        pay_methods = [
            ("cash",      "💵 Cash on Delivery"),
            ("easypaisa", "📱 Easypaisa"),
            ("jazzcash",  "📱 JazzCash"),
            ("card",      "💳 Debit/Credit Card"),
        ]
        for i, (v, lbl) in enumerate(pay_methods):
            tk.Radiobutton(opt_frame, text=lbl, variable=pay_var,
                           value=v, bg=BG, fg=TEXT,
                           selectcolor=CARD,
                           activebackground=BG, activeforeground=GOLD,
                           font=("Segoe UI", 10),
                           command=lambda: _show_pay_fields()
                           ).grid(row=1 + i // 2, column=1 + i % 2,
                                  padx=4, pady=2, sticky="w")

        pay_detail_frame = tk.Frame(body, bg=CARD,
                                    highlightbackground=BORDER,
                                    highlightthickness=1)
        pay_detail_frame.pack(fill="x", pady=4)

        pay_detail_inner = tk.Frame(pay_detail_frame, bg=CARD, padx=12, pady=8)
        pay_detail_inner.pack(fill="x")

        pay_field_vars: dict[str, tk.StringVar] = {
            "number":  tk.StringVar(),
            "name":    tk.StringVar(),
            "expiry":  tk.StringVar(),
            "cvv":     tk.StringVar(),
        }

        def _pay_entry(parent, label: str, var: tk.StringVar,
                       show: str = "", width: int = 22) -> tk.Entry:
            r = tk.Frame(parent, bg=CARD)
            r.pack(fill="x", pady=2)
            tk.Label(r, text=label, width=18, anchor="w",
                     font=("Segoe UI", 9), fg=MUTED, bg=CARD).pack(side="left")
            e = tk.Entry(r, textvariable=var, show=show,
                         width=width, font=("Segoe UI", 9),
                         bg=INPUT, fg=TEXT,
                         insertbackground=GOLD,
                         relief="flat", bd=0)
            e.pack(side="left", ipady=3)
            return e

        def _clear_detail():
            for w in pay_detail_inner.winfo_children():
                w.destroy()
            for v in pay_field_vars.values():
                v.set("")

        def _show_pay_fields():
            _clear_detail()
            method = pay_var.get()
            if method == "cash":
                tk.Label(pay_detail_inner,
                         text="💵  Pay the rider when your order arrives.",
                         font=("Segoe UI", 9), fg=MUTED, bg=CARD).pack(anchor="w")
            elif method == "easypaisa":
                tk.Label(pay_detail_inner,
                         text="📱  Easypaisa Mobile Account",
                         font=("Segoe UI", 9, "bold"), fg=GOLD2, bg=CARD
                         ).pack(anchor="w", pady=(0, 4))
                _pay_entry(pay_detail_inner, "Easypaisa Number:", pay_field_vars["number"])
                _pay_entry(pay_detail_inner, "Account Name:",     pay_field_vars["name"])
            elif method == "jazzcash":
                tk.Label(pay_detail_inner,
                         text="📱  JazzCash Mobile Account",
                         font=("Segoe UI", 9, "bold"), fg=GOLD2, bg=CARD
                         ).pack(anchor="w", pady=(0, 4))
                _pay_entry(pay_detail_inner, "JazzCash Number:", pay_field_vars["number"])
                _pay_entry(pay_detail_inner, "Account Name:",    pay_field_vars["name"])
            elif method == "card":
                tk.Label(pay_detail_inner,
                         text="💳  Debit / Credit Card",
                         font=("Segoe UI", 9, "bold"), fg=GOLD2, bg=CARD
                         ).pack(anchor="w", pady=(0, 4))
                _pay_entry(pay_detail_inner, "Card Number:",     pay_field_vars["number"])
                _pay_entry(pay_detail_inner, "Cardholder Name:", pay_field_vars["name"])
                row2 = tk.Frame(pay_detail_inner, bg=CARD)
                row2.pack(fill="x")
                tk.Label(row2, text="Expiry (MM/YY):", width=18, anchor="w",
                         font=("Segoe UI", 9), fg=MUTED, bg=CARD).pack(side="left")
                tk.Entry(row2, textvariable=pay_field_vars["expiry"],
                         width=8, font=("Segoe UI", 9),
                         bg=INPUT, fg=TEXT, insertbackground=GOLD,
                         relief="flat", bd=0).pack(side="left", ipady=3, padx=(0, 12))
                tk.Label(row2, text="CVV:", font=("Segoe UI", 9),
                         fg=MUTED, bg=CARD).pack(side="left")
                tk.Entry(row2, textvariable=pay_field_vars["cvv"],
                         width=5, show="•", font=("Segoe UI", 9),
                         bg=INPUT, fg=TEXT, insertbackground=GOLD,
                         relief="flat", bd=0).pack(side="left", ipady=3)

        _show_pay_fields()

        def place_order():
            if not self.cart:
                messagebox.showwarning("Empty Cart", "Add items first.", parent=cwin)
                return
            method = pay_var.get()
            if method in ("easypaisa", "jazzcash"):
                if not pay_field_vars["number"].get().strip():
                    messagebox.showwarning(
                        "Payment Details",
                        f"Please enter your "
                        f"{'Easypaisa' if method == 'easypaisa' else 'JazzCash'} number.",
                        parent=cwin)
                    return
            elif method == "card":
                if not pay_field_vars["number"].get().strip():
                    messagebox.showwarning("Payment Details",
                                           "Please enter your card number.", parent=cwin)
                    return
                if not pay_field_vars["expiry"].get().strip():
                    messagebox.showwarning("Payment Details",
                                           "Please enter the card expiry date.", parent=cwin)
                    return
                if not pay_field_vars["cvv"].get().strip():
                    messagebox.showwarning("Payment Details",
                                           "Please enter the CVV.", parent=cwin)
                    return

            rid      = self.cart[0]["restaurant_id"]
            rest_obj = next((r for r in self.restaurants
                             if r["restaurant_id"] == rid),
                            {"restaurant_id": rid, "name": "Restaurant"})
            address  = self.user.get("address", "") or "Not specified"
            try:
                order_id = models.place_order(
                    user_id         = self.user["user_id"],
                    customer_name   = self.user["name"],
                    customer_email  = self.user["email"],
                    restaurant_id   = rid,
                    restaurant_name = rest_obj["name"],
                    address         = address,
                    items           = self.cart,
                    payment_method  = pay_var.get(),
                    delivery_type   = delivery_var.get(),
                )
            except Exception as exc:
                messagebox.showerror("Order Failed", str(exc), parent=cwin)
                return

            self.cart.clear()
            self.cart_restaurant_id = None
            cwin.destroy()
            messagebox.showinfo(
                "Order Placed! 🎉",
                f"Order {order_id} placed successfully!\n"
                "Check 'My Orders' to track delivery.",
            )
            self.nb.select(1)
            self._load_my_orders()

        tk.Button(body, text="✅ Place Order", command=place_order,
                  bg=SUCCESS, fg=TEXT,
                  font=("Segoe UI", 13, "bold"),
                  relief="flat", cursor="hand2", pady=10
                  ).pack(fill="x", pady=10)

    # ══════════════════════════════════════════════════════════════════════
    # TAB 2 — MY ORDERS
    # ══════════════════════════════════════════════════════════════════════
    def _tab_orders(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  📦 My Orders  ")

        top = tk.Frame(frame, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="My Orders",
                 font=("Georgia", 14, "bold"),
                 fg=GOLD, bg=BG).pack(side="left")
        tk.Button(top, text="↻ Refresh", command=self._load_my_orders,
                  bg=GOLD3, fg=TEXT, font=("Segoe UI", 9),
                  relief="flat", cursor="hand2", padx=10).pack(side="right")

        pane = tk.PanedWindow(frame, orient="vertical", bg=BG, sashwidth=6)
        pane.pack(fill="both", expand=True, padx=10, pady=4)

        top_pane = tk.Frame(pane, bg=BG)
        pane.add(top_pane, minsize=200)

        cols = ("Order ID", "Restaurant", "Total", "Type", "Status", "Date")
        self.orders_tree = ttk.Treeview(top_pane, columns=cols,
                                         show="headings", height=10)
        for c in cols:
            self.orders_tree.heading(c, text=c)
        self.orders_tree.column("Order ID",   width=140)
        self.orders_tree.column("Restaurant", width=180)
        self.orders_tree.column("Total",      width=90,  anchor="e")
        self.orders_tree.column("Type",       width=80,  anchor="center")
        self.orders_tree.column("Status",     width=150)
        self.orders_tree.column("Date",       width=100)

        vsb = ttk.Scrollbar(top_pane, orient="vertical",
                             command=self.orders_tree.yview)
        self.orders_tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.orders_tree.pack(fill="both", expand=True)

        bot_pane = tk.Frame(pane, bg=CARD)
        pane.add(bot_pane, minsize=180)

        tracker_f = tk.Frame(bot_pane, bg=CARD)
        tracker_f.pack(fill="x", padx=14, pady=(10, 4))
        tk.Label(tracker_f, text="Order Progress",
                 font=("Segoe UI", 10, "bold"),
                 fg=GOLD2, bg=CARD).pack(anchor="w")

        self.tracker_canvas = tk.Canvas(tracker_f, bg=CARD, height=52,
                                         highlightthickness=0)
        self.tracker_canvas.pack(fill="x", pady=4)

        detail_f = tk.Frame(bot_pane, bg=CARD, padx=14)
        detail_f.pack(fill="x")
        self.detail_lbl = tk.Label(detail_f,
                                    text="Select an order to see details.",
                                    font=("Segoe UI", 10),
                                    fg=MUTED, bg=CARD,
                                    justify="left", anchor="w")
        self.detail_lbl.pack(fill="x")

        self.review_btn = tk.Button(
            bot_pane,
            text="⭐ Leave a Review  (select a delivered order)",
            command=self._open_review_popup,
            bg=GOLD3, fg=GOLD,
            disabledforeground="#4A3A20",
            font=("Segoe UI", 10, "bold"),
            relief="flat", cursor="hand2",
            padx=16, pady=6, state="disabled")
        self.review_btn.pack(anchor="e", padx=14, pady=6)

        self.orders_tree.bind("<<TreeviewSelect>>", self._on_order_select)
        self.after(100, self._load_my_orders)

    def _load_my_orders(self):
        self.my_orders: list[dict] = models.get_orders(
            user_id=self.user["user_id"])
        self.orders_tree.delete(*self.orders_tree.get_children())
        for o in self.my_orders:
            self.orders_tree.insert("", "end", values=(
                o["order_id"],
                o.get("restaurant_name") or o.get("restaurant", ""),
                f"Rs. {o['total']:.2f}",
                o.get("delivery_type", "Delivery"),
                o["status"].title(),
                str(o["order_date"])[:10],
            ))

    def _on_order_select(self, _event):
        sel = self.orders_tree.selection()
        if not sel:
            return
        idx  = self.orders_tree.index(sel[0])
        self._selected_order = self.my_orders[idx]
        order = self._selected_order

        # ── FIX 3: derive step from status string, not missing status_step field ──
        status_str = order.get("status", "pending").lower()
        step = STATUS_MAP.get(status_str, 1)
        self.after(10, lambda: self._draw_tracker(step, status_str))

        items = models.get_order_items(order["order_id"])
        lines = [
            f"• {i['item_name']} ×{i['quantity']}  Rs.{i['unit_price']:.2f}"
            for i in items
        ]
        rider = order.get("rider_name") or order.get("rider", "")
        if rider:
            lines.append(f"🛵 Rider: {rider}")
        self.detail_lbl.config(
            text="  ".join(lines) if lines else "No items found.",
            fg=TEXT,
        )

        # ── FIX 4: check Reviews table to prevent duplicate review buttons ──
        already_reviewed = models.has_review(
            self.user["user_id"], order["order_id"])
        can_review = (status_str == "delivered") and not already_reviewed

        if can_review:
            self.review_btn.config(
                state="normal",
                text="⭐ Leave a Review",
                bg=GOLD2, fg=BG, cursor="hand2",
            )
        else:
            hint = "(already reviewed)" if (status_str == "delivered" and already_reviewed) \
                   else "(select a delivered order)"
            self.review_btn.config(
                state="disabled",
                text=f"⭐ Leave a Review  {hint}",
                bg=GOLD3, cursor="arrow",
            )

    def _draw_tracker(self, step: int, status: str):
        c = self.tracker_canvas
        c.delete("all")
        c.update_idletasks()
        W  = c.winfo_width() or 700
        n  = len(STATUS_STEPS)
        sw = W / n
        cancelled = status == "cancelled"

        for i, (label, icon) in enumerate(STATUS_STEPS):
            cx     = sw * i + sw / 2
            active = (not cancelled) and (i + 1 <= step)

            if i < n - 1:
                color = GOLD3 if (not cancelled and i + 1 < step) else BORDER
                c.create_line(cx + 14, 20, sw * (i + 1) + sw / 2 - 14, 20,
                              fill=color, width=3)

            if cancelled and i == 0:
                circle_color = DANGER
            elif active:
                circle_color = GOLD3
            else:
                circle_color = BORDER

            c.create_oval(cx - 14, 6, cx + 14, 34,
                          fill=circle_color, outline="")
            c.create_text(cx, 20,
                          text=(icon if active else "○"),
                          font=("Segoe UI Emoji", 10), fill=TEXT)
            c.create_text(cx, 44, text=label,
                          font=("Segoe UI", 8), fill=GOLD2)

    # ══════════════════════════════════════════════════════════════════════
    # REVIEW POPUP
    # ══════════════════════════════════════════════════════════════════════
    def _open_review_popup(self):
        if self._selected_order is None:
            return
        order = self._selected_order

        popup = tk.Toplevel(self)
        popup.title("Leave a Review")
        popup.configure(bg=BG)
        popup.grab_set()
        self._center_toplevel(popup, 460, 390)

        hdr = tk.Frame(popup, bg=HEADER, height=50)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="⭐  Leave a Review",
                 font=("Georgia", 13, "bold"),
                 fg=GOLD, bg=HEADER).pack(side="left", padx=16)

        body = tk.Frame(popup, bg=BG, padx=24, pady=16)
        body.pack(fill="both", expand=True)

        rest_name = order.get("restaurant_name") or order.get("restaurant", "")

        info = tk.Frame(body, bg=CARD,
                        highlightbackground=BORDER, highlightthickness=1)
        info.pack(fill="x", pady=(0, 12))
        tk.Label(info,
                 text=f"📦  Order: {order['order_id']}   🏠  {rest_name}",
                 font=("Segoe UI", 9), fg=GOLD2, bg=CARD,
                 pady=6).pack(anchor="w", padx=10)
        tk.Label(info,
                 text="Only delivered orders can be reviewed. "
                      "Select a star rating, write your comment, then press Submit.",
                 font=("Segoe UI", 8), fg=MUTED, bg=CARD,
                 wraplength=400, justify="left").pack(anchor="w", padx=10, pady=(0, 6))

        tk.Label(body, text="Your Rating:",
                 font=("Segoe UI", 10, "bold"), fg=TEXT, bg=BG).pack(anchor="w")
        rating_var = tk.IntVar(value=5)
        star_frame = tk.Frame(body, bg=BG)
        star_frame.pack(anchor="w", pady=4)
        star_btns: list[tk.Label] = []

        rating_hint = tk.Label(body, text="5 stars selected",
                               font=("Segoe UI", 9), fg=MUTED, bg=BG)
        rating_hint.pack(anchor="w")

        def _set_rating(v: int):
            rating_var.set(v)
            labels = ["", "Poor", "Fair", "Good", "Very Good", "Excellent"]
            rating_hint.config(text=f"{v} star{'s' if v > 1 else ''} — {labels[v]}")
            for j, s in enumerate(star_btns):
                s.config(fg=GOLD if j < v else MUTED)

        for v in range(1, 6):
            s = tk.Label(star_frame, text="★", font=("Segoe UI", 20),
                         fg=GOLD if v <= 5 else MUTED,
                         bg=BG, cursor="hand2")
            s.pack(side="left", padx=2)
            s.bind("<Button-1>", lambda e, val=v: _set_rating(val))
            s.bind("<Enter>",    lambda e, val=v: [b.config(
                fg=GOLD if i < val else MUTED) for i, b in enumerate(star_btns)])
            s.bind("<Leave>",    lambda e: _set_rating(rating_var.get()))
            star_btns.append(s)

        _set_rating(5)

        tk.Label(body, text="Your Comment:",
                 font=("Segoe UI", 10, "bold"), fg=TEXT, bg=BG).pack(anchor="w", pady=(8, 2))
        comment_txt = tk.Text(body, height=5,
                              font=("Segoe UI", 10),
                              relief="flat", bd=0,
                              bg=INPUT, fg=TEXT,
                              insertbackground=GOLD,
                              wrap="word",
                              highlightbackground=BORDER,
                              highlightthickness=1)
        comment_txt.pack(fill="x", pady=4)
        placeholder = "Write what you liked or didn't like…"
        comment_txt.insert("1.0", placeholder)
        comment_txt.config(fg=MUTED)

        def _clear_placeholder(e):
            if comment_txt.get("1.0", "end-1c") == placeholder:
                comment_txt.delete("1.0", "end")
                comment_txt.config(fg=TEXT)
        comment_txt.bind("<FocusIn>", _clear_placeholder)

        def submit():
            comment = comment_txt.get("1.0", "end-1c").strip()
            if not comment or comment == placeholder:
                messagebox.showwarning("Missing",
                                       "Please write a comment before submitting.",
                                       parent=popup)
                return
            try:
                models.add_review(
                    order_id        = order["order_id"],
                    user_id         = self.user["user_id"],
                    restaurant_id   = order.get("restaurant_id"),
                    restaurant_name = rest_name,
                    customer_email  = self.user["email"],
                    rating          = rating_var.get(),
                    comment         = comment,
                )
            except Exception as exc:
                messagebox.showerror("Error", str(exc), parent=popup)
                return

            messagebox.showinfo("Thank you!", "Your review has been submitted! ⭐",
                                parent=popup)
            popup.destroy()
            self._load_my_orders()
            self.review_btn.config(state="disabled", bg=GOLD3, cursor="arrow",
                                   text="⭐ Leave a Review  (already reviewed)")

        tk.Button(body, text="⭐  Submit Review", command=submit,
                  bg=GOLD2, fg=BG,
                  font=("Segoe UI", 11, "bold"),
                  relief="flat", cursor="hand2", pady=9
                  ).pack(fill="x", pady=8)

    # ══════════════════════════════════════════════════════════════════════
    # TAB 3 — PROFILE (EDITABLE)
    # ══════════════════════════════════════════════════════════════════════
    def _tab_profile(self):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text="  👤 Profile  ")

        card = tk.Frame(frame, bg=CARD, padx=30, pady=30)
        card.pack(padx=80, pady=40, fill="both", expand=True)

        tk.Label(card, text="My Profile",
                 font=("Georgia", 16, "bold"),
                 fg=GOLD, bg=CARD).pack(anchor="w", pady=(0, 20))

        fields_frame = tk.Frame(card, bg=CARD)
        fields_frame.pack(fill="x")

        self._profile_vars: dict[str, tk.StringVar] = {}
        editable = ["name", "phone", "address"]
        labels   = {
            "name":    "Name",
            "email":   "Email",
            "phone":   "Phone",
            "address": "Address",
        }

        for key in ["name", "email", "phone", "address"]:
            row = tk.Frame(fields_frame, bg=CARD)
            row.pack(fill="x", pady=5)
            tk.Label(row, text=f"{labels[key]}:",
                     width=10, anchor="w",
                     font=("Segoe UI", 11, "bold"),
                     fg=GOLD2, bg=CARD).pack(side="left")
            var = tk.StringVar(value=self.user.get(key, ""))
            self._profile_vars[key] = var
            if key in editable:
                tk.Entry(row, textvariable=var,
                         font=("Segoe UI", 11),
                         bg=INPUT, fg=TEXT,
                         insertbackground=GOLD,
                         relief="flat", bd=0, width=30
                         ).pack(side="left")
            else:
                tk.Label(row, textvariable=var,
                         font=("Segoe UI", 11),
                         fg=MUTED, bg=CARD).pack(side="left")

        tk.Frame(card, bg=BORDER, height=1).pack(fill="x", pady=14)

        # ── Change Password section ───────────────────────────────────────
        tk.Label(card, text="Change Password",
                 font=("Georgia", 12, "bold"),
                 fg=GOLD, bg=CARD).pack(anchor="w")

        pass_frame = tk.Frame(card, bg=CARD)
        pass_frame.pack(fill="x", pady=6)

        self._cur_pass_var     = tk.StringVar()
        self._new_pass_var     = tk.StringVar()
        self._confirm_pass_var = tk.StringVar()

        # ── password field helper with eye toggle ─────────────────────────
        def _pw_row(parent, label_text: str, var: tk.StringVar):
            r = tk.Frame(parent, bg=CARD)
            r.pack(fill="x", pady=3)
            tk.Label(r, text=f"{label_text}:", width=18, anchor="w",
                     font=("Segoe UI", 10), fg=GOLD2, bg=CARD).pack(side="left")

            wrapper = tk.Frame(r, bg=INPUT,
                               highlightthickness=1,
                               highlightbackground=BORDER,
                               highlightcolor=GOLD)
            wrapper.pack(side="left")

            entry = tk.Entry(wrapper, textvariable=var, show="•",
                             font=("Segoe UI", 10),
                             bg=INPUT, fg=TEXT,
                             insertbackground=GOLD,
                             relief="flat", bd=0, width=22)
            entry.pack(side="left", ipady=4, padx=(6, 0))

            visible  = tk.BooleanVar(value=False)
            btn_ref  = [None]

            def _toggle(e=entry, v=visible, ref=btn_ref):
                v.set(not v.get())
                e.configure(show="" if v.get() else "•")
                ref[0].configure(text="🙈" if v.get() else "👁")

            eye_btn = tk.Button(wrapper, text="👁",
                                font=("Segoe UI Emoji", 11),
                                bg=INPUT, fg=MUTED,
                                relief="flat", bd=0, cursor="hand2",
                                activebackground=INPUT, activeforeground=GOLD,
                                command=_toggle)
            eye_btn.pack(side="left", padx=(2, 4))
            btn_ref[0] = eye_btn

            def on_focus_in(e, w=wrapper):
                w.config(highlightbackground=GOLD)
            def on_focus_out(e, w=wrapper):
                w.config(highlightbackground=BORDER)
            entry.bind("<FocusIn>",  on_focus_in)
            entry.bind("<FocusOut>", on_focus_out)

        _pw_row(pass_frame, "Current Password", self._cur_pass_var)
        _pw_row(pass_frame, "New Password",      self._new_pass_var)
        _pw_row(pass_frame, "Confirm Password",  self._confirm_pass_var)

        # Inline status label so no popup needed for password errors
        self._pw_status_lbl = tk.Label(card, text="",
                                        font=("Segoe UI", 9),
                                        bg=CARD, fg=SUCCESS_FG)
        self._pw_status_lbl.pack(anchor="w", pady=(4, 0))

        # ── Action buttons ────────────────────────────────────────────────
        btn_row = tk.Frame(card, bg=CARD)
        btn_row.pack(fill="x", pady=16)

        tk.Button(btn_row, text="💾 Save Profile",
                  command=self._save_profile,
                  bg=GOLD3, fg=TEXT,
                  font=("Segoe UI", 11, "bold"),
                  relief="flat", cursor="hand2",
                  padx=20, pady=8).pack(side="left")

        tk.Button(btn_row, text="🔑 Change Password",
                  command=self._change_password,
                  bg="#1A2F5A", fg=GOLD,
                  font=("Segoe UI", 11, "bold"),
                  relief="flat", cursor="hand2",
                  padx=20, pady=8).pack(side="left", padx=12)

    def _save_profile(self):
        name    = self._profile_vars["name"].get().strip()
        phone   = self._profile_vars["phone"].get().strip()
        address = self._profile_vars["address"].get().strip()

        if not name:
            messagebox.showwarning("Validation", "Name cannot be empty.")
            return

        ok, _ = auth.update_profile(
            self.user["email"],
            name    = name,
            phone   = phone,
            address = address,
        )
        if ok:
            self.user["name"]    = name
            self.user["phone"]   = phone
            self.user["address"] = address
            messagebox.showinfo("Saved", "Profile updated successfully! ✅")
        else:
            messagebox.showerror("Error", "Could not update profile.")

    def _change_password(self):
        """
        FIX 1 & 2: verify current password first, then call auth.change_password()
        (plain-text consistent with auth.py — no hashing mismatch).
        """
        cur     = self._cur_pass_var.get().strip()
        new     = self._new_pass_var.get().strip()
        confirm = self._confirm_pass_var.get().strip()

        lbl = self._pw_status_lbl

        if not cur or not new or not confirm:
            lbl.config(text="⚠  All three password fields are required.", fg=WARN_FG)
            return
        if not auth.verify_password(self.user["email"], cur):
            lbl.config(text="✖  Current password is incorrect.", fg=DANGER_FG)
            return
        if new != confirm:
            lbl.config(text="⚠  New passwords do not match.", fg=WARN_FG)
            return
        if len(new) < 6:
            lbl.config(text="⚠  Password must be at least 6 characters.", fg=WARN_FG)
            return

        # FIX 1: use auth.change_password — no hashing, consistent with auth.login()
        auth.change_password(self.user["email"], new)

        self._cur_pass_var.set("")
        self._new_pass_var.set("")
        self._confirm_pass_var.set("")
        lbl.config(text="✔  Password changed successfully!", fg=SUCCESS_FG)