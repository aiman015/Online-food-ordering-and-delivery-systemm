# windows/login_window.py — Savoria Login & Register (Dark Luxury)

import tkinter as tk
from tkinter import messagebox
import auth

# Dark luxury palette
BG_DARK     = "#0D0A14"   # near-black deep purple (main bg)
BG_CARD     = "#160F2A"   # slightly lighter dark purple (card/content)
BG_INPUT    = "#1E1535"   # input field background
PURPLE_RICH = "#2A1650"   # header background
GOLD        = "#C9A84C"   # rich gold
GOLD2       = "#E8C46A"   # lighter gold (hover/highlight)
GOLD_DIM    = "#8A6A1F"   # dimmed gold (borders)
WHITE       = "#F0E6FF"   # soft white with purple tint
MUTED       = "#7A6A9A"   # muted purple-grey
BORDER      = "#2E1F50"   # subtle border color

WIN_W = 480

class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Savoria — Order Food Delivery")
        self.resizable(False, False)
        self.configure(bg=BG_DARK)
        self.current_user = None
        self._build_ui()
        self.center()

    def center(self):
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        win_h = min(740, int(sh * 0.88))
        self.geometry(f"{WIN_W}x{win_h}+{(sw - WIN_W)//2}+{(sh - win_h)//2}")

    def _build_ui(self):
        # ── Hero ──
        hdr = tk.Frame(self, bg=PURPLE_RICH, height=160)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Frame(hdr, bg=GOLD, height=3).pack(side="top", fill="x")
        tk.Frame(hdr, bg=GOLD_DIM, height=1).pack(side="bottom", fill="x")

        inner = tk.Frame(hdr, bg=PURPLE_RICH)
        inner.pack(expand=True)
        tk.Label(inner, text="🍽", font=("Segoe UI Emoji", 34),
                 fg=GOLD, bg=PURPLE_RICH).pack(pady=(10, 0))
        tk.Label(inner, text="Savoria",
                 font=("Georgia", 28, "bold"),
                 fg=GOLD2, bg=PURPLE_RICH).pack()
        tk.Label(inner, text="✦  Order Food Delivery  ✦",
                 font=("Segoe UI", 9), fg=GOLD_DIM, bg=PURPLE_RICH).pack()

        # ── Tabs ──
        tab_row = tk.Frame(self, bg=BG_CARD, height=44)
        tab_row.pack(fill="x")
        tab_row.pack_propagate(False)
        tk.Frame(self, bg=GOLD_DIM, height=1).pack(fill="x")

        self.login_btn = tk.Button(
            tab_row, text="🔑  Login",
            font=("Segoe UI", 11, "bold"),
            bg=BG_CARD, fg=MUTED, relief="flat", cursor="hand2", bd=0,
            activebackground=PURPLE_RICH, activeforeground=GOLD,
            command=lambda: self._switch("login"))
        self.login_btn.pack(side="left", fill="both", expand=True)

        tk.Frame(tab_row, bg=GOLD_DIM, width=1).pack(side="left", fill="y")

        self.reg_btn = tk.Button(
            tab_row, text="🆕  Register",
            font=("Segoe UI", 11, "bold"),
            bg=PURPLE_RICH, fg=GOLD, relief="flat", cursor="hand2", bd=0,
            activebackground=PURPLE_RICH, activeforeground=GOLD2,
            command=lambda: self._switch("register"))
        self.reg_btn.pack(side="left", fill="both", expand=True)

        # ── Scrollable content ──
        self.canvas = tk.Canvas(self, bg=BG_DARK,
                                highlightthickness=0, bd=0)
        self.scrollbar = tk.Scrollbar(self, orient="vertical",
                                      command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.content = tk.Frame(self.canvas, bg=BG_DARK)
        self._content_window = self.canvas.create_window(
            (0, 0), window=self.content, anchor="nw")

        self.content.bind("<Configure>", self._on_frame_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind_all("<MouseWheel>",
            lambda e: self.canvas.yview_scroll(-1*(e.delta//120), "units"))

        self._build_login()
        self._build_register()
        self._switch("login")

    def _on_frame_configure(self, event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        if self.content.winfo_reqheight() <= self.canvas.winfo_height():
            self.scrollbar.pack_forget()
        else:
            self.scrollbar.pack(side="right", fill="y")

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self._content_window, width=event.width)

    def _switch(self, tab):
        self.canvas.yview_moveto(0)
        if tab == "login":
            self.login_btn.config(bg=PURPLE_RICH, fg=GOLD)
            self.reg_btn.config(bg=BG_CARD, fg=MUTED)
            self.reg_frame.pack_forget()
            self.login_frame.pack(fill="both", expand=True)
        else:
            self.reg_btn.config(bg=PURPLE_RICH, fg=GOLD)
            self.login_btn.config(bg=BG_CARD, fg=MUTED)
            self.login_frame.pack_forget()
            self.reg_frame.pack(fill="both", expand=True)

    # ── Login tab ──
    def _build_login(self):
        self.login_frame = tk.Frame(self.content, bg=BG_DARK)

        tk.Label(self.login_frame, text="Welcome back 👋",
                 font=("Georgia", 16, "bold"), fg=GOLD2, bg=BG_DARK
                 ).pack(pady=(28, 3))
        tk.Label(self.login_frame, text="Sign in to continue ordering",
                 font=("Segoe UI", 10), fg=MUTED, bg=BG_DARK
                 ).pack(pady=(0, 20))

        self.login_email = self._field(self.login_frame, "📧  Email address")
        self.login_pass  = self._password_field(self.login_frame, "🔒  Password")

        self._gold_btn(self.login_frame, "✦  Sign In", self._do_login)

        tk.Label(self.login_frame,
                 text="Demo: admin@savoria.com / admin123",
                 font=("Segoe UI", 9), fg=MUTED, bg=BG_DARK).pack(pady=4)

        tk.Frame(self.login_frame, bg=GOLD_DIM, height=1
                 ).pack(fill="x", padx=32, pady=14)

        tk.Label(self.login_frame, text="New to Savoria?",
                 font=("Segoe UI", 9), fg=MUTED, bg=BG_DARK).pack()
        tk.Button(self.login_frame, text="Create a free account →",
                  font=("Segoe UI", 9, "bold"), fg=GOLD, bg=BG_DARK,
                  relief="flat", cursor="hand2",
                  activeforeground=GOLD2, activebackground=BG_DARK,
                  command=lambda: self._switch("register")).pack(pady=(2, 28))

    def _do_login(self):
        email    = self.login_email.get().strip()
        password = self.login_pass.get().strip()
        ok, result = auth.login(email, password)
        if not ok:
            messagebox.showerror("Login Failed", result, parent=self)
            return
        self.current_user = result
        self.destroy()

    # ── Register tab ──
    def _build_register(self):
        self.reg_frame = tk.Frame(self.content, bg=BG_DARK)

        tk.Label(self.reg_frame, text="Join Savoria 🎉",
                 font=("Georgia", 16, "bold"), fg=GOLD2, bg=BG_DARK
                 ).pack(pady=(24, 3))
        tk.Label(self.reg_frame, text="Create your free account",
                 font=("Segoe UI", 10), fg=MUTED, bg=BG_DARK
                 ).pack(pady=(0, 12))

        self.reg_name  = self._field(self.reg_frame, "👤  Full name")
        self.reg_email = self._field(self.reg_frame, "📧  Email address")
        self.reg_phone = self._field(self.reg_frame, "📱  Phone number")
        self.reg_pass  = self._password_field(self.reg_frame, "🔒  Password")

        role_f = tk.Frame(self.reg_frame, bg=BG_DARK)
        role_f.pack(fill="x", padx=32, pady=(8, 0))
        tk.Label(role_f, text="I am a:", font=("Segoe UI", 10, "bold"),
                 fg=GOLD, bg=BG_DARK).pack(side="left", padx=(0, 10))
        self.reg_role = tk.StringVar(value="customer")
        for val, lbl in [("customer", "🛍 Customer"),
                          ("owner",    "🍳 Restaurant Owner")]:
            tk.Radiobutton(role_f, text=lbl, variable=self.reg_role,
                           value=val, bg=BG_DARK, fg=WHITE,
                           selectcolor=BG_DARK,
                           activebackground=BG_DARK, activeforeground=GOLD,
                           font=("Segoe UI", 10)).pack(side="left", padx=4)

        self._gold_btn(self.reg_frame, "✦  Create Account", self._do_register)

        tk.Label(self.reg_frame, text="Already have an account?",
                 font=("Segoe UI", 9), fg=MUTED, bg=BG_DARK).pack()
        tk.Button(self.reg_frame, text="Sign in here →",
                  font=("Segoe UI", 9, "bold"), fg=GOLD, bg=BG_DARK,
                  relief="flat", cursor="hand2",
                  activeforeground=GOLD2, activebackground=BG_DARK,
                  command=lambda: self._switch("login")).pack(pady=(2, 28))

    def _do_register(self):
        ok, result = auth.register(
            self.reg_name.get().strip(),
            self.reg_email.get().strip(),
            self.reg_phone.get().strip(),
            '',
            self.reg_pass.get().strip(),
            self.reg_role.get()
        )
        if not ok:
            messagebox.showerror("Registration Failed", result, parent=self)
            return
        messagebox.showinfo("🎉 Welcome!", "Account created! Please log in.", parent=self)
        self._switch("login")

    # ── Helpers ──
    def _field(self, parent, label, show=None):
        tk.Label(parent, text=label, font=("Segoe UI", 10, "bold"),
                 fg=GOLD, bg=BG_DARK, anchor="w"
                 ).pack(fill="x", padx=32, pady=(8, 2))
        e = tk.Entry(parent, font=("Segoe UI", 11), relief="flat", bd=0,
                     show=show or '', bg=BG_INPUT, fg=WHITE,
                     insertbackground=GOLD,
                     highlightthickness=1,
                     highlightcolor=GOLD,
                     highlightbackground=BORDER)
        e.pack(fill="x", padx=32, ipady=9)
        return e

    def _password_field(self, parent, label):
        """Password field with eye toggle button to show/hide text."""
        tk.Label(parent, text=label, font=("Segoe UI", 10, "bold"),
                 fg=GOLD, bg=BG_DARK, anchor="w"
                 ).pack(fill="x", padx=32, pady=(8, 2))

        # Outer wrapper with same look as a normal input
        wrapper = tk.Frame(parent, bg=BG_INPUT,
                           highlightthickness=1,
                           highlightbackground=BORDER,
                           highlightcolor=GOLD)
        wrapper.pack(fill="x", padx=32)

        entry = tk.Entry(wrapper, font=("Segoe UI", 11), relief="flat", bd=0,
                         show="•", bg=BG_INPUT, fg=WHITE,
                         insertbackground=GOLD)
        entry.pack(side="left", fill="both", expand=True, ipady=9, padx=(8, 0))

        # Track visibility state
        visible = tk.BooleanVar(value=False)

        def toggle():
            if visible.get():
                entry.config(show="•")
                visible.set(False)
                eye_btn.config(text="👁")
            else:
                entry.config(show="")
                visible.set(True)
                eye_btn.config(text="🙈")

        eye_btn = tk.Button(wrapper, text="👁",
                            font=("Segoe UI Emoji", 12),
                            bg=BG_INPUT, fg=MUTED,
                            relief="flat", bd=0, cursor="hand2",
                            activebackground=BG_INPUT, activeforeground=GOLD,
                            command=toggle)
        eye_btn.pack(side="right", padx=(0, 6))

        # Highlight wrapper border on entry focus
        def on_focus_in(e):
            wrapper.config(highlightbackground=GOLD)
        def on_focus_out(e):
            wrapper.config(highlightbackground=BORDER)

        entry.bind("<FocusIn>",  on_focus_in)
        entry.bind("<FocusOut>", on_focus_out)

        return entry

    def _gold_btn(self, parent, text, cmd):
        tk.Button(parent, text=text, command=cmd,
                  bg=GOLD_DIM, fg=GOLD2,
                  font=("Segoe UI", 11, "bold"),
                  relief="flat", cursor="hand2", pady=11,
                  activebackground=GOLD, activeforeground=BG_DARK
                  ).pack(fill="x", padx=32, pady=14)