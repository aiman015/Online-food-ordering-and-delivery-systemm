#!/usr/bin/env python3
# main.py — Savoria Desktop App Entry Point

import tkinter as tk
from tkinter import messagebox

import db
ok, info = db.test_connection()
if not ok:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(
        "Database Connection Failed",
        f"Could not connect to SQL Server.\n\nError: {info}\n\n"
        f"Steps to fix:\n"
        f"1. Open db.py\n"
        f"2. Set SERVER to your SSMS server name\n"
        f"3. Make sure SQL Server is running\n"
        f"4. Run sql/create_tables.sql in SSMS first",
        parent=root
    )
    root.destroy()
    raise SystemExit(1)

from windows.login_window   import LoginWindow
from windows.customer_window import CustomerWindow
from windows.admin_window   import AdminWindow
from windows.owner_window   import OwnerWindow


def main():
    while True:
        # Show login window
        login = LoginWindow()
        login.mainloop()

        user = login.current_user
        if not user:
            break  # user closed login → quit

        role = user.get('role', 'customer')

        # Create a hidden root to host the dashboard
        root = tk.Tk()
        root.withdraw()

        if role == 'admin':
            win = AdminWindow(root, user)
        elif role == 'owner':
            win = OwnerWindow(root, user)
        else:
            win = CustomerWindow(root, user)

        # When dashboard closes, destroy root and loop back to login
        win.protocol("WM_DELETE_WINDOW", lambda: (win.destroy(), root.destroy()))
        root.mainloop()


if __name__ == "__main__":
    main()