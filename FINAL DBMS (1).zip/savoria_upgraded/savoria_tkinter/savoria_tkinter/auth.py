# auth.py — Login & register logic for Savoria (no hashing)
import db

def register(name, email, phone, address, password, role='customer'):
    if not name or not email or not password:
        return False, "Name, email and password are required."

    if role not in ('customer', 'owner'):
        role = 'customer'

    email = email.strip().lower()
    existing = db.fetchone("SELECT user_id FROM Users WHERE email = ?", [email])
    if existing:
        return False, "An account with this email already exists."

    new_id = db.execute_identity(
        "INSERT INTO Users (name, email, phone, address, password, role) VALUES (?,?,?,?,?,?)",
        [name, email, phone or '', address or '', password, role]
    )
    user = db.fetchone(
        "SELECT user_id, name, email, phone, address, role FROM Users WHERE user_id = ?",
        [new_id]
    )
    return True, user


def login(email, password):
    if not email or not password:
        return False, "Email and password are required."

    email = email.strip().lower()
    row = db.fetchone(
        "SELECT user_id, name, email, phone, address, role, password FROM Users WHERE email = ? AND is_deleted = 0",
        [email]
    )
    if not row:
        return False, "Invalid email or password."

    if row['password'] != password:
        return False, "Invalid email or password."

    row.pop('password', None)
    return True, row


def update_profile(email, name=None, phone=None, address=None):
    parts = []
    params = []
    if name    is not None: parts.append("name = ?");    params.append(name)
    if phone   is not None: parts.append("phone = ?");   params.append(phone)
    if address is not None: parts.append("address = ?"); params.append(address)
    if not parts:
        return False, "Nothing to update."
    params.append(email.lower())
    db.execute(f"UPDATE Users SET {', '.join(parts)} WHERE email = ?", params)
    return True, None


def get_all_users():
    return db.fetchall(
        "SELECT user_id, name, email, phone, address, role, created_at FROM Users WHERE is_deleted=0 ORDER BY created_at DESC"
    )


def delete_user(email):
    db.execute("UPDATE Users SET is_deleted=1 WHERE email=?", [email.lower()])


def verify_password(email: str, plain_password: str) -> bool:
    """Return True if plain_password matches the stored password for email."""
    row = db.fetchone(
        "SELECT password FROM Users WHERE email = ? AND is_deleted = 0",
        [email.strip().lower()]
    )
    if not row:
        return False
    return row['password'] == plain_password


def change_password(email: str, new_password: str) -> None:
    """Persist new_password for the account with email."""
    db.execute(
        "UPDATE Users SET password = ? WHERE email = ? AND is_deleted = 0",
        [new_password, email.strip().lower()]
    )