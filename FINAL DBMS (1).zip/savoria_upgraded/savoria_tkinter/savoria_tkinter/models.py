# models.py — All business logic for Savoria
# Covers: restaurants, menu items, orders, reviews, riders, reports

import uuid
import datetime
import db


# ══════════════════════════════════════════════════════════════
#  RESTAURANTS
# ══════════════════════════════════════════════════════════════

def get_restaurants(status='active'):
    if status == 'all':
        return db.fetchall("SELECT * FROM Restaurants WHERE is_deleted=0 ORDER BY name")
    return db.fetchall(
        "SELECT * FROM Restaurants WHERE is_deleted=0 AND status=? ORDER BY name", [status]
    )


def add_restaurant(owner_id, name, cuisine, category, location, contact):
    new_id = db.execute_identity(
        "INSERT INTO Restaurants (owner_id, name, cuisine, category, location, contact, status) "
        "VALUES (?,?,?,?,?,?,'pending')",
        [owner_id, name, cuisine, category, location, contact]
    )
    return db.fetchone("SELECT * FROM Restaurants WHERE restaurant_id=?", [new_id])


def update_restaurant_status(restaurant_id, status):
    db.execute("UPDATE Restaurants SET status=? WHERE restaurant_id=?", [status, restaurant_id])


def get_owner_restaurant(owner_id):
    return db.fetchone(
        "SELECT * FROM Restaurants WHERE owner_id=? AND is_deleted=0", [owner_id]
    )


# ══════════════════════════════════════════════════════════════
#  MENU ITEMS
# ══════════════════════════════════════════════════════════════

def get_menu_items(restaurant_id=None, category=None):
    sql = "SELECT * FROM Menu_Items WHERE is_deleted=0 AND availability=1"
    params = []
    if restaurant_id:
        sql += " AND restaurant_id=?"; params.append(restaurant_id)
    if category:
        sql += " AND category=?"; params.append(category)
    sql += " ORDER BY category, name"
    return db.fetchall(sql, params)


def get_menu_categories(restaurant_id):
    rows = db.fetchall(
        "SELECT DISTINCT category FROM Menu_Items WHERE restaurant_id=? AND is_deleted=0 AND availability=1",
        [restaurant_id]
    )
    return [r['category'] for r in rows]


def add_menu_item(restaurant_id, name, description, price, category, image_url=''):
    return db.execute_identity(
        "INSERT INTO Menu_Items (restaurant_id, name, description, price, category, image_url) "
        "VALUES (?,?,?,?,?,?)",
        [restaurant_id, name, description, price, category, image_url]
    )


def update_menu_item(item_id, name=None, price=None, description=None,
                     category=None, availability=None):
    parts, params = [], []
    if name         is not None: parts.append("name=?");         params.append(name)
    if price        is not None: parts.append("price=?");        params.append(price)
    if description  is not None: parts.append("description=?");  params.append(description)
    if category     is not None: parts.append("category=?");     params.append(category)
    if availability is not None: parts.append("availability=?"); params.append(int(availability))
    if not parts:
        return
    params.append(item_id)
    db.execute(f"UPDATE Menu_Items SET {', '.join(parts)} WHERE item_id=?", params)


def delete_menu_item(item_id):
    db.execute("UPDATE Menu_Items SET is_deleted=1 WHERE item_id=?", [item_id])


# ══════════════════════════════════════════════════════════════
#  ORDERS
# ══════════════════════════════════════════════════════════════

# Maps UI payment method labels → DB values
PAYMENT_METHOD_MAP = {
    'Cash on Delivery': 'cash',
    'Easypaisa':        'easypaisa',
    'JazzCash':         'jazzcash',
    'Debit/Credit Card':'card',
    # lowercase passthrough (already correct)
    'cash':             'cash',
    'easypaisa':        'easypaisa',
    'jazzcash':         'jazzcash',
    'card':             'card',
}

# Maps order status → valid Delivery.delivery_status values
DELIVERY_STATUS_MAP = {
    'pending':          'pending',
    'accepted':         'pending',
    'preparing':        'pending',
    'out for delivery': 'out for delivery',
    'ready for pickup': 'pending',
    'delivered':        'delivered',
    'cancelled':        'cancelled',
}


def place_order(user_id, customer_name, customer_email, restaurant_id,
                restaurant_name, address, items, payment_method='cash',
                delivery_type='Delivery'):
    """
    items = list of dicts: {item_id, name, qty, price}
    Returns order_id string.
    """
    # Normalize payment method to DB-safe value
    payment_method = PAYMENT_METHOD_MAP.get(payment_method, 'cash')

    order_id     = f"ORD-{uuid.uuid4().hex[:8].upper()}"
    subtotal     = sum(i['qty'] * i['price'] for i in items)
    delivery_fee = 0.0 if delivery_type == 'Pickup' else 50.0
    total        = subtotal + delivery_fee
    today        = datetime.date.today()

    # Assign a rider
    rider = db.fetchone(
        "SELECT name FROM Riders WHERE is_available=1 ORDER BY NEWID()"
    )
    rider_name = rider['name'] if rider else 'TBD'

    db.execute(
        "INSERT INTO Orders (order_id, user_id, customer_email, customer_name, "
        "restaurant, restaurant_id, address, subtotal, delivery_fee, total, "
        "status, status_step, delivery_type, rider, order_date) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,'pending',1,?,?,?)",
        [order_id, user_id, customer_email, customer_name,
         restaurant_name, restaurant_id, address,
         subtotal, delivery_fee, total, delivery_type, rider_name, today]
    )

    for item in items:
        db.execute(
            "INSERT INTO Order_Items (order_id, item_id, item_name, quantity, unit_price) "
            "VALUES (?,?,?,?,?)",
            [order_id, item.get('item_id'), item['name'], item['qty'], item['price']]
        )

    # Payment record — method is now normalized to DB-safe value
    db.execute(
        "INSERT INTO Payments (order_id, method, payment_status) VALUES (?,?,'paid')",
        [order_id, payment_method]
    )

    # Delivery record
    db.execute(
        "INSERT INTO Delivery (order_id, rider_name, delivery_status) VALUES (?,?,'pending')",
        [order_id, rider_name]
    )

    return order_id


def get_orders(user_id=None, email=None, restaurant_id=None, status=None):
    sql = """
        SELECT o.*, r.name AS restaurant_name,
               p.method AS payment_method, p.payment_status,
               d.rider_name, d.delivery_status
        FROM Orders o
        LEFT JOIN Restaurants r ON r.restaurant_id = o.restaurant_id
        LEFT JOIN Payments    p ON p.order_id = o.order_id
        LEFT JOIN Delivery    d ON d.order_id = o.order_id
        WHERE 1=1
    """
    params = []
    if user_id:       sql += " AND o.user_id=?";       params.append(user_id)
    if email:         sql += " AND o.customer_email=?"; params.append(email.lower())
    if restaurant_id: sql += " AND o.restaurant_id=?"; params.append(restaurant_id)
    if status:        sql += " AND o.status=?";         params.append(status)
    sql += " ORDER BY o.placed_at DESC"
    return db.fetchall(sql, params)


def get_order_items(order_id):
    return db.fetchall(
        "SELECT * FROM Order_Items WHERE order_id=?", [order_id]
    )


def update_order_status(order_id, status):
    step_map = {
        'pending': 1, 'accepted': 2, 'preparing': 3,
        'out for delivery': 4, 'ready for pickup': 4,
        'delivered': 5, 'cancelled': 0
    }
    step = step_map.get(status, 1)
    delivered_at = "GETDATE()" if status == 'delivered' else "NULL"

    db.execute(
        f"UPDATE Orders SET status=?, status_step=?, delivered_at={delivered_at} WHERE order_id=?",
        [status, step, order_id]
    )

    # Normalize to a value allowed by CK_Delivery_Status
    delivery_status = DELIVERY_STATUS_MAP.get(status, 'pending')
    db.execute(
        "UPDATE Delivery SET delivery_status=? WHERE order_id=?",
        [delivery_status, order_id]
    )


def get_all_orders(status=None):
    return get_orders(status=status)


# ══════════════════════════════════════════════════════════════
#  REVIEWS
# ══════════════════════════════════════════════════════════════

def add_review(order_id, user_id, restaurant_id, restaurant_name,
               customer_email, rating, comment):
    db.execute(
        "INSERT INTO Reviews (order_id, user_id, restaurant_id, restaurant, customer_email, rating, comment) "
        "VALUES (?,?,?,?,?,?,?)",
        [order_id, user_id, restaurant_id, restaurant_name, customer_email, rating, comment]
    )
    db.execute("UPDATE Orders SET reviewed=1 WHERE order_id=?", [order_id])
    avg = db.fetchone(
        "SELECT AVG(CAST(rating AS FLOAT)) AS avg_rating FROM Reviews WHERE restaurant_id=?",
        [restaurant_id]
    )
    if avg and avg['avg_rating']:
        db.execute(
            "UPDATE Restaurants SET rating=? WHERE restaurant_id=?",
            [round(avg['avg_rating'], 2), restaurant_id]
        )


def get_reviews(restaurant_id=None):
    sql = "SELECT * FROM Reviews"
    params = []
    if restaurant_id:
        sql += " WHERE restaurant_id=?"; params.append(restaurant_id)
    sql += " ORDER BY created_at DESC"
    return db.fetchall(sql, params)


def get_all_reviews(restaurant_id=None):
    """Return all reviews joined with user name and restaurant name.
    Used by the admin Reviews tab."""
    sql = """
        SELECT r.review_id, r.order_id, r.rating,
               r.comment, r.created_at,
               u.name  AS customer_name,
               re.name AS restaurant_name,
               r.restaurant_id
        FROM   Reviews r
        LEFT JOIN Users       u  ON u.user_id        = r.user_id
        LEFT JOIN Restaurants re ON re.restaurant_id = r.restaurant_id
    """
    params = []
    if restaurant_id:
        sql += " WHERE r.restaurant_id=?"; params.append(restaurant_id)
    sql += " ORDER BY r.created_at DESC"
    return db.fetchall(sql, params)


def has_review(user_id: int, order_id) -> bool:
    """Return True if this user already reviewed this order."""
    row = db.fetchone(
        "SELECT review_id FROM Reviews WHERE user_id=? AND order_id=?",
        [user_id, order_id]
    )
    return row is not None


def delete_review(review_id: int):
    db.execute("DELETE FROM Reviews WHERE review_id=?", [review_id])


# ══════════════════════════════════════════════════════════════
#  RIDERS
# ══════════════════════════════════════════════════════════════

def get_riders():
    return db.fetchall("SELECT * FROM Riders ORDER BY name")


def add_rider(name, phone, vehicle='Bike', zone='General'):
    db.execute_identity(
        "INSERT INTO Riders (name, phone, vehicle, zone) VALUES (?,?,?,?)",
        [name, phone, vehicle, zone]
    )


def toggle_rider(rider_id):
    db.execute(
        "UPDATE Riders SET is_available = CASE WHEN is_available=1 THEN 0 ELSE 1 END WHERE rider_id=?",
        [rider_id]
    )


def delete_rider(rider_id):
    db.execute("DELETE FROM Riders WHERE rider_id=?", [rider_id])


# ══════════════════════════════════════════════════════════════
#  REPORTS
# ══════════════════════════════════════════════════════════════

def get_summary():
    total_orders  = db.fetchone("SELECT COUNT(*) AS c FROM Orders")['c']
    total_revenue = db.fetchone(
        "SELECT ISNULL(SUM(total),0) AS s FROM Orders WHERE status='delivered'"
    )['s']
    total_users   = db.fetchone("SELECT COUNT(*) AS c FROM Users WHERE is_deleted=0")['c']
    pending       = db.fetchone("SELECT COUNT(*) AS c FROM Orders WHERE status='pending'")['c']
    return {
        'total_orders':   total_orders,
        'total_revenue':  float(total_revenue),
        'total_users':    total_users,
        'pending_orders': pending,
    }


def get_sales_report(days=30):
    return db.fetchall(
        "SELECT CAST(order_date AS NVARCHAR) AS date, COUNT(*) AS orders, "
        "SUM(total) AS revenue FROM Orders "
        "WHERE order_date >= DATEADD(DAY, -?, CAST(GETDATE() AS DATE)) "
        "AND status != 'cancelled' "
        "GROUP BY order_date ORDER BY order_date",
        [days]
    )


def get_average_rating() -> float:
    """System-wide average rating across all reviews."""
    row = db.fetchone("SELECT ROUND(AVG(CAST(rating AS FLOAT)), 2) AS avg FROM Reviews")
    return float(row["avg"]) if row and row["avg"] else 0.0


def get_top_restaurants(limit: int = 10) -> list:
    """Restaurants ranked by total revenue from delivered orders."""
    return db.fetchall(
        """SELECT re.restaurant_id, re.name, re.cuisine,
                  COUNT(o.order_id)         AS total_orders,
                  COALESCE(SUM(o.total), 0) AS total_revenue,
                  COALESCE(re.rating, 0)    AS avg_rating
           FROM   Restaurants re
           LEFT JOIN Orders o
                  ON o.restaurant_id = re.restaurant_id
                 AND o.status = 'delivered'
           GROUP  BY re.restaurant_id, re.name, re.cuisine, re.rating
           ORDER  BY total_revenue DESC
           OFFSET 0 ROWS FETCH NEXT ? ROWS ONLY""",
        [limit]
    )


def get_payment_breakdown() -> list:
    """Order count and revenue grouped by payment method."""
    return db.fetchall(
        """SELECT p.method                   AS payment_method,
                  COUNT(p.payment_id)        AS order_count,
                  COALESCE(SUM(o.total), 0)  AS total_revenue
           FROM   Payments p
           JOIN   Orders   o ON o.order_id = p.order_id
           GROUP  BY p.method
           ORDER  BY total_revenue DESC"""
    )


def get_restaurant_sales_summary(restaurant_id: int) -> dict:
    """KPI summary for a single restaurant."""
    row = db.fetchone(
        """SELECT COUNT(*)                                         AS total_orders,
                  COALESCE(SUM(total), 0)                         AS total_revenue,
                  COUNT(CASE WHEN status='delivered'  THEN 1 END) AS delivered_orders,
                  COUNT(CASE WHEN status NOT IN
                        ('delivered','cancelled') THEN 1 END)     AS pending_orders
           FROM   Orders
           WHERE  restaurant_id = ?""",
        [restaurant_id]
    )
    return dict(row) if row else {}


def get_top_menu_items(restaurant_id: int, limit: int = 10) -> list:
    """Best-selling menu items for a restaurant."""
    return db.fetchall(
        """SELECT mi.name, mi.category,
                  COALESCE(SUM(oi.quantity), 0)                AS units_sold,
                  COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS revenue
           FROM   Menu_Items mi
           LEFT JOIN Order_Items oi ON oi.item_id  = mi.item_id
           LEFT JOIN Orders      o  ON o.order_id  = oi.order_id
                                   AND o.status    = 'delivered'
           WHERE  mi.restaurant_id = ?
           GROUP  BY mi.item_id, mi.name, mi.category
           ORDER  BY units_sold DESC
           OFFSET 0 ROWS FETCH NEXT ? ROWS ONLY""",
        [restaurant_id, limit]
    )