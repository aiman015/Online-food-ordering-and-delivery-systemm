# db.py — SQL Server connection for Savoria
# Uses pyodbc to connect to Microsoft SQL Server (SSMS)
#
# SETUP:
#   pip install pyodbc bcrypt
#   Install ODBC Driver 17 for SQL Server from Microsoft
#
# Edit SERVER and DATABASE below to match your SSMS setup.

import pyodbc

# ── Connection settings — edit these to match your SSMS setup ──
SERVER   = r'localhost\SQLEXPRESS'   # or just 'localhost' for full SQL Server
DATABASE = 'savoria_db'
# For Windows Authentication (recommended for local dev):
USE_WINDOWS_AUTH = True
# For SQL Server Authentication, set USE_WINDOWS_AUTH = False and fill:
SQL_USER     = 'sa'
SQL_PASSWORD = 'YourPassword'

_conn = None

def get_connection():
    global _conn
    try:
        if _conn and _conn.cursor():
            return _conn
    except Exception:
        _conn = None

    if USE_WINDOWS_AUTH:
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={SERVER};"
            f"DATABASE={DATABASE};"
            f"Trusted_Connection=yes;"
            f"TrustServerCertificate=yes;"
        )
    else:
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={SERVER};"
            f"DATABASE={DATABASE};"
            f"UID={SQL_USER};"
            f"PWD={SQL_PASSWORD};"
            f"TrustServerCertificate=yes;"
        )
    _conn = pyodbc.connect(conn_str, autocommit=False)
    return _conn


def execute(sql, params=None):
    """Run INSERT/UPDATE/DELETE. Returns rows affected."""
    conn = get_connection()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    conn.commit()
    return cur.rowcount


def fetchall(sql, params=None):
    """Run SELECT. Returns list of dicts."""
    conn = get_connection()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]


def fetchone(sql, params=None):
    """Run SELECT. Returns single dict or None."""
    rows = fetchall(sql, params)
    return rows[0] if rows else None


def execute_identity(sql, params=None):
    """INSERT and return the new IDENTITY id."""
    conn = get_connection()
    cur  = conn.cursor()
    cur.execute(sql, params or [])
    cur.execute("SELECT SCOPE_IDENTITY()")
    new_id = cur.fetchone()[0]
    conn.commit()
    return int(new_id) if new_id else None


def test_connection():
    """Returns (True, server_info) or (False, error_message)."""
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("SELECT @@VERSION")
        ver = cur.fetchone()[0]
        return True, ver.split('\n')[0]
    except Exception as e:
        return False, str(e)